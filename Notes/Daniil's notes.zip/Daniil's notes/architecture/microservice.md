# Microservice architecture

Such apps consist of loosely coupled services that communicate with each other.

Key traits:
1. Loose coupling with other services
2. Deployable independently

As a consequence, each microservice may be developed by a small team.

## Example

Frontend (communicates with API gateway only)  
Browser  
Mobile  

API Gateway (single entry point for all clients, calls services APIs that are needed)

Backend (each one has its own REST API endpoint)  
Service A  
Service B  
Service C  

Database (each database is only connected to one service)  
Database A  
Database B  
Database C  

## Benefits

1. Easy to maintain, test, deploy
2. Small, capable of being developed by a small team
3. Fault isolation: a faulty service will not break an entire app
4. Easy to scale by adding resources for a particularly heavy service

## Drabacks

1. Developers need to deal with distributed system complexity (inter-service communication, teams coordination)
2. Increased resource consumption - there is additional overhead for runtimes and communication

## When to use

Small apps don't have the problems that this pattern solves.
It should only be used for mature apps.
When a monolithic app starts to grow, it's better to decompose it into services.

There are lots of ways to decompose a monolithic app:
1. By business capabilities
2. By domain
3. By use cases

## Other points

FK constraints have to be maintained by app code when communicating between services.
