# Serverless architecture

Serverless is a cloud computing model in which cloud allocates server resources on demand.

Server is still needed despite the name, but in some cases it may not be used at all times.
