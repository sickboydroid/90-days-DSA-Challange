# Monolithic architecture

Monolithic apps are self-contained and their backend may be run in a single runtime.
All aspects of such apps (data processing, error handling, UI) are interconnected and interdependent.

## Example

Browser app <-> (Load balancer) <-> App backend / server <-> Database

## Benefits vs drawbacks

| Stage | Initial | Later |
| --- | --- | --- |
| Development | Simple, everything is in one place | Size confuses developers, hard to ramp up; IDE lag |
| Deployment | Simple, just one runtime needed | Takes a long time to start up / update the app |
| Scaling | Simple, just multiply instances behind a load balancer | Inefficient: 1) DB access is shared; 2) Components have different resource requirements |

## When to use

This pattern is perfect for the first version of the application.
More elaborate architecture options will slow down MVP development.
