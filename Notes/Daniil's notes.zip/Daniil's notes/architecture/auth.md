# Authentication and Authorization

Authentication is for checking that the user is indeed who they claim to be.

Authorization is for checking whether the user is allowed to access a resource.

Both happen on client's request.

## Basic flow

Authentication: client signs in and receives a secure cookie that has to be used in every request to the server.

Authorization: client makes a request; server parses cookie and checks which user it belongs to; server checks whether the user has access to the resource.

## Session vs JWT

Session:
- Client makes request to the server with credentials
- Server creates a session and stores it in DB
- Server sends session ID as a cookie
- Client sends cookie with each request
- Server checks for session ID in DB
- Server sends respone or error

JWT:
- Client makes request to the server with credentials
- Server creates JWT and signs it using a secret; no data is stored
- Server sends JWT as a cookie
- Client sends JWT with each request
- Server verifies JWT signature using a secret
- Server sends response or error

## OAuth flow

### Roles
- Client: web app
- User: end user of the web app or web app itself
- Authorization server: verifies identity of the user and issues tokens
- Resource server: protected resource source

### Implicit flow

1. Client sends authorization request to the user
2. User grants permission to authorize
3. Client redirects the user to the authorization server, user authorizes
4. Authorization server returns access token and redirects back to the client
5. Client uses this token to access the resource server

### Authorization code flow

1. Client sends authorization request to the user
2. User grants permission to authorize
3. Client redirects the user to the authorization server, user authorizes
4. Authorization server returns **short-lived authorization code**
5. **Client presents authorization code to token endpoint of authorization server**
6. **Token endpoint of authorization server returns access token**
7. Client uses this token to access the resource server

### Refresh tokens

When issuing access tokens, authorization server may also return a refresh token.  
Access tokens are short-lived, and refresh token may be used to get a new access token.  
Once client uses the refresh token, both old access and refresh tokens become outdated.
The response to the refresh request is the same as the original request's response - access token and a refresh token.
