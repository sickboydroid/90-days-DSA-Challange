# API Gateway

An API gateway is a single entry point for all clients.
It handles incoming requests in one of two ways:
1. Route to the appropriate service
2. Call multiple services

## Benefits

1. Clients are isolated from how the microservices are partitioned
2. Reduces the number of requests for the client (request aggregation)
3. Extracts the logic for multi-service requests for clients
4. In case of multiple different gateways, each client gets an optimized API

## Drawbacks

1. Increased complexity due to one more component needed in the system
2. Increased response time for single service requests
