# Load balancers

Load balancers distribute client requests to application servers or databases.

## Principle

1. Pick a worker to forward the request to
2. Wait for response
3. Send response to client

There are different ways of choosing the worker, e.g. randomly, least-busy, ...

## Benefits

- The load is distributed
- SSL termination - balancer can decrypt requests and encrypt responses, which is safer and removes the need to install X.509 certificates to each server.
