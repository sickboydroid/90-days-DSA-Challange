/**
 * Create a class that only has one instance.
 * This is useful for IO-systems and data bases, since they should only have one instance.
 */

class Singleton {
  private Singleton() {}

  private static Singleton instance = null;
  public static Singleton getInstance() {
    if (instance == null) {
      return new Singleton();
    } else {
      return instance;
    }
  }
}
