/**
 * Allows to create recursive structures of nested objects.
 *
 * This is useful in a tree-like structure, like a file system.
 */

import java.util.ArrayList;
import java.util.List;

abstract class File {
  public String name;
}

class Folder extends File {
  private List<File> nestedFiles = new ArrayList<File>();;

  public Folder(String name) {
    this.name = name;
  }

  public void add(File child) {
    nestedFiles.add(child);
  }

  public void printDir(int level) {
    for (int i = 0; i < level; i++) {
      System.out.print("\t");
    }
    System.out.println(name);

    nestedFiles.forEach(file -> {
      if (file instanceof Folder) {
        ((Folder)file).printDir(level + 1);
      } else {
        for (int i = 0; i < level + 1; i++) {
          System.out.print("\t");
        }
        System.out.println(file.name);
      }
    });
  }
  public void printDir() {
    printDir(0);
  }
}

class DataFile extends File {
  private byte[] data;
  public DataFile(String name) {
    this.name = name;
  }

  public void rewrite(byte[] newData) {
    data = newData;
  }

  public byte[] read() {
    return data;
  }
}

class Main {
  public static void main(String[] args) {
    Folder root = new Folder("root");

    Folder photosFolder = new Folder("photos");
    photosFolder.add(new Folder("old"));
    photosFolder.add(new DataFile("somePicture.png"));
    photosFolder.add(new DataFile("someOtherPicture.jpg"));

    Folder codeFolder = new Folder("code");
    codeFolder.add(new DataFile("Composite.java"));

    root.add(photosFolder);
    root.add(codeFolder);

    root.printDir();
  }
}
