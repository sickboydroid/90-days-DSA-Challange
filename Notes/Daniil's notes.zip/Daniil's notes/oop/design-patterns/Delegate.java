/**
 * Problem: class A has some functionality that class B wants to have, but doesn't want to implement.
 * Solution: instance of B delegates its calls to an instance of A.
 * Now B has the required methods or fields but does not actually implement them.
 * 
 * This is a dangerous pattern to use.
 * Changes to B may implicitly break A.
 * Since B is dependent on A, the open-closed principle is broken.
 */

class A {
  void method1() {
    System.out.println("Method 1");
  }

  void method2() {
    System.out.println("Method 2");
  }
}

class B {
  A a = new A();

  void method1() {
    a.method1();
  }

  void method2() {
    a.method2();
  }
}
