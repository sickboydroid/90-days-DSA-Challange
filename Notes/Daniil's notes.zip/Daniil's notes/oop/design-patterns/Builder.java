/**
 * Problem: a constructor is bloated - too many arguments, arguments with repeating types.
 *
 * Solution: create a separate builder class.
 * It has setSomething(value) methods that are used instead of arguments.
 * To create the final object we call build() function.
 *
 * Builder is useful to:
 * 1) Hide the object creation's details
 * 2) Create a complex object with many attributes that can be set in any order
 *
 * Difference between builder and factory method:
 * factory: an object is created with a single method call (factory method is essentially a wrapper around constructor)
 * builder: an object is created with multiple method calls (each one sets possible object's properties)
 */

class Meal {
  public final boolean hasSoup;
  public final boolean hasDessert;
  public final boolean hasTea;
  public final boolean hasCoffe;

  public Meal(
    boolean hasSoup,
    boolean hasDessert,
    boolean hasTea,
    boolean hasCoffe
  ) {
    this.hasSoup = hasSoup;
    this.hasDessert = hasDessert;
    this.hasTea = hasTea;
    this.hasCoffe = hasCoffe;
  }
}

// Builder
class Waitress {
  private boolean willBringSoup;
  private boolean willBringDessert;
  private boolean willBringTea;
  private boolean willBringCoffe;

  public void askToBringSoup() {
    willBringSoup = true;
  }
  public void askToBringDessert() {
    willBringDessert = true;
  }

  // Some arguments may be overlapping. It's easier to handle these cases with a builder class
  public void askToBringTea() {
    willBringTea = true;
    willBringCoffe = false;
  }
  public void askToBringCoffe() {
    willBringTea = false;
    willBringCoffe = true;
  }

  public Meal askToBringMeal() {
    return new Meal(
      willBringSoup,
      willBringDessert,
      willBringTea,
      willBringCoffe
    );
  }
}
