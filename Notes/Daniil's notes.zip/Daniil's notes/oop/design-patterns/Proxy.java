/**
 * Proxy is the substitude of some object that that intercepts all or some of the calls made to that object.
 * It can be thought of as a shell that may alter the way the object is interacted with.
 *
 * There are numerous ways of processing the incoming requests by the proxy, such as:
 * - Logging
 * - Caching
 * - Protection from unsafe calls
 * - etc.
 */

class UnsafeObject {
  public String operation(String s) {
    return "" + s.charAt(0) + s.charAt(1);
  }
}

class ProtectorProxy extends UnsafeObject {
  @Override
  public String operation(String s) {
    if (s.length() < 2) {
      return s;
    }

    return super.operation(s);
  }
}
