/**
 * This pattern is used to create a family of classes with similar behavior.
 * Create an abstract class that will have:
 * - A lot of abstract methods, which may vary between classes
 * - One or few defined methods that call the abstract methods
 *
 * Each abstract method is called the right way / with the right kind and number of parameters.
 *
 * This result is a template class that reduces behavior duplication.
 * 
 * Similar to strategy, but:
 * - Strategy is mostly used in runtime, and template method is used in compile time via subclasses
 * - Strategy typically has only one method, and implementations don't have to have similar structure
 */

abstract class Enemy {
  protected abstract void lookForPlayer();
  protected abstract void moveTo(double x, double y);
  protected abstract void castAttack(double x, double y);

  // Template methods
  public void idle() {
    while (true) {
      moveTo(Math.random(), Math.random());
      lookForPlayer();
    }
  }

  public void attack(Player player) {
    while (true) {
      moveTo(player.x, player.y);
      castAttack(player.x, player.y);
    }
  }
}

class Player {
  double x;
  double y;

  // ...
}

// Some classes can opt to not change any template methods
class Zombie extends Enemy {
  @Override
  protected void lookForPlayer() { }
  @Override
  protected void moveTo(double x, double y) { }
  @Override
  protected void castAttack(double x, double y) { }
}

// Others can change them if they want to
class Skeleton extends Enemy {
  @Override
  protected void lookForPlayer() { }
  @Override
  protected void moveTo(double x, double y) { }
  @Override
  protected void castAttack(double x, double y) { }

  @Override
  public void attack(Player player) {
    while (true) {
      moveTo(Math.random(), Math.random());
      castAttack(player.x, player.y);
    }
  }
}
