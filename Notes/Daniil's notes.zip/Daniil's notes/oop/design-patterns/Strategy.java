/**
 * This pattern is used if a class may have multiple sets of behavior (strategies).
 * These behaviors may be changed dynamically.
 * The strategy object calls the main methods of this class when it's needed to make a decision or execute an action.
 */

abstract class FighterBehaviour {
  public abstract boolean shouldAttackWeaker();
  public abstract boolean shouldAttackEqual();
  public abstract boolean shouldAttackStronger();
}

class RookieBehaviour extends FighterBehaviour {
  @Override
  public boolean shouldAttackWeaker() {
    return true;
  }
  @Override
  public boolean shouldAttackEqual() {
    return true;
  }
  @Override
  public boolean shouldAttackStronger() {
    return true;
  }
}

class ExperiencedBehaviour extends FighterBehaviour {
  @Override
  public boolean shouldAttackWeaker() {
    return false;
  }
  @Override
  public boolean shouldAttackEqual() {
    return true;
  }
  @Override
  public boolean shouldAttackStronger() {
    return false;
  }
}

class InsaneBehaviour extends FighterBehaviour {
  @Override
  public boolean shouldAttackWeaker() {
    return Math.random() < 0.5;
  }
  @Override
  public boolean shouldAttackEqual() {
    return Math.random() < 0.5;
  }
  @Override
  public boolean shouldAttackStronger() {
    return Math.random() < 0.5;
  }
}

class Fighter {
  private FighterBehaviour behaviour;
  int strength;

  public Fighter(String description) {
    switch (description) {
      case "Rookie":
        behaviour = new RookieBehaviour();
        strength = 5;
        break;
      case "Experienced":
        behaviour = new ExperiencedBehaviour();
        strength = 25;
        break;
      case "Insane":
        behaviour = new InsaneBehaviour();
        strength = 15;
        break;
    }
  }

  public void fight(Fighter other) {
    boolean shouldAttack = false;
    if (other.strength < this.strength) {
      shouldAttack = behaviour.shouldAttackWeaker();
    }
    if (other.strength == this.strength) {
      shouldAttack = behaviour.shouldAttackEqual();
    }
    if (other.strength > this.strength) {
      shouldAttack = behaviour.shouldAttackStronger();
    }

    // Do something
  }
}
