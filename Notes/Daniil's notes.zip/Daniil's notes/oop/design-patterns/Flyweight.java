/**
 * Problem: objects share duplicate data.
 * Solution: store duplicate data in a separate object. Replace duplicate fields with pointers to this data.
 *
 * This allows to only store intrinsic state inside the object.
 */

class Game {
  private Sprite[] sprites;

  public Game() {
    sprites = new Sprite[3];

    var sprite1 = Sprite.createBreadSprite(15, 30);
    var sprite2 = Sprite.createBreadSprite(10, 10);
    var sprite3 = Sprite.createCakeSprite(20, 20);
  }
}

class Sprite {
  private int posX;
  private int posY;
  private int[][] image;

  private Sprite(int posX, int posY, int[][] image) {
    this.posX = posX;
    this.posX = posY;
    this.image = image;
  }

  private static int[][] cakeImage = somehowLoadImage("cake.png");
  private static int[][] breadImage = somehowLoadImage("bread.png");

  public static Sprite createCakeSprite(int posX, int posY) {
    return new Sprite(posX, posY, cakeImage);
  }

  public static Sprite createBreadSprite(int posX, int posY) {
    return new Sprite(posX, posY, breadImage);
  }
}
