/**
 * This pattern is used when one of multiple handlers should process a particular event.
 * This allows to achieve loose coupling because event dispatcher and handler are separated.
 * Each handler decides whether to handle the event or to pass the event further.
 * 
 * This pattern is nearly identical to the Decorator pattern.
 * The difference is that in decorator all classes handle the event, not a single one.
 *
 * This pattern can be thought of as of a dynamic switch statement.
 */

import java.util.ArrayList;
import java.util.List;

class Event {
  String data;
  public Event(String data) {
    this.data = data;
  }
}

interface Handler {
  public boolean shouldHandle(Event e);
  public boolean handle(Event e);
}

class HandlerChain {
  List<Handler> handlers = new ArrayList<>();

  public HandlerChain add(Handler handler) {
    handlers.add(handler);
    return this;
  }

  public void dispatch(Event event) {
    for (Handler handler : handlers) {
      if (handler.shouldHandle(event)) {
        handler.handle(event);
        return;
      }
    }
  }
}
