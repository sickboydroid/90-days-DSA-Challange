/**
 * Suppose we need to track changes of some object.
 * Many objects may need that object's state.
 * 
 * We may create a "subscription" system:
 * - Observers subscribe (they are added to the subscribers list)
 * - Once some event happens, each subscriber is notified about it
 */

import java.util.ArrayList;

interface Observer<T> {
  public void handleEvent(T event);
}

abstract class Observable<T> {
  private ArrayList<Observer<T>> observers = new ArrayList<>();

  public void addListener(Observer<T> observer) {
    observers.add(observer);
  }
  public void removeListener(Observer<T> observer) {
    observers.remove(observer);
  }
  public void dispatchEvent(T event) {
    observers.forEach((observer) -> observer.handleEvent(event));
  }
}

class Youtuber extends Observable<String> {
  public void makeVideo(String videoTitle) {
    dispatchEvent(videoTitle);
  }
}

class Subscriber implements Observer<String> {
  private int moodLevel;

  public Subscriber(int moodLevel) {
    if (moodLevel < 0 || moodLevel > 10) {
      throw new IndexOutOfBoundsException();
    }

    this.moodLevel = moodLevel;
  }

  @Override
  public void handleEvent(String event) {
    String reaction = (moodLevel < 5) ? "dislike" : "like";
    System.out.println("Watched " + event + "; Reaction: " + reaction);
  }
}

class Main {
  public static void main(String[] args) {
    Youtuber t = new Youtuber();

    t.addListener(new Subscriber(3));
    t.addListener(new Subscriber(5));
    t.addListener(new Subscriber(7));
    t.addListener(new Subscriber(1));
    t.addListener(new Subscriber(8));
    t.addListener(new Subscriber(10));

    t.makeVideo("Cat video");
  }
}
