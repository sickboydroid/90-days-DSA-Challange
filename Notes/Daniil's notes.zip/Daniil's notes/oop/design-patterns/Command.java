/**
 * Allows to use objects to represent different commands that can be executed by another object.
 * These command objects incapsulate blocks of code that can be called later.
 * In functional programming, same functionality is achieved by passing functions by reference.
 * The command objects often have an undo() method.
 *
 * This pattern is usually used when a particular block of code can be executed from different places.
 */

import java.util.ArrayList;

interface Command {
  public void execute();
}

class Strategy implements Command {
  private ArrayList<Command> commands;

  public void addCommand(Command newCommand) {
    commands.add(newCommand);
  }

  public void execute() {
    commands.forEach(Command::execute);
  }
}

class Enemy {
  Strategy idleMetStrategy;
  Strategy enemyMetStrategy;
  Strategy allyMetStrategy;

  // ...
}
