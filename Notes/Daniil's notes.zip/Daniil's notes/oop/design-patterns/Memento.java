/**
 * Suppose some object's state has to be saved and restored later.
 * Shallow copying doesn't store all data.
 * Deep cloning isn't efficient because some fields may not need to be stored.
 *
 * The memento patterns suggests saving object's state in a dedicated state object
 * Later, object's state can be restored using the state object.
 */

import java.util.List;
import java.util.stream.Collectors;

class Enemy {
  int health;
  float x;
  float y;

  static Enemy copy(Enemy other) {
    Enemy copy = new Enemy();
    copy.health = other.health;
    copy.x = other.x;
    copy.y = other.y;
    return copy;
  }
}

// Memento
class Save {
  long tick;
  List<Enemy> enemies;
  float x;
  float y;
  Save(long tick, List<Enemy> enemies, float x, float y) {
    this.tick = tick;
    this.enemies = enemies;
    this.x = x;
    this.y = y;
  }
}

class Game {
  long tick;
  // If we used default cloning behaviour then nested classes would not be
  // saved properly
  List<Enemy> enemies;
  float x;
  float y;
  // Some fields don't need to be stored at all, cloning would be inefficient
  // in that case
  long ticksSinceLastLoad;

  Save save() {
    List<Enemy> savedEnemies = enemies
      .stream()
      .map(Enemy::copy)
      .collect(Collectors.toList());

    return new Save(tick, savedEnemies, x, y);
  }

  void load(Save s) {
    this.tick = s.tick;
    this.enemies = s.enemies;
    this.x = s.x;
    this.y = s.y;
    this.ticksSinceLastLoad = 0;
  }
}
