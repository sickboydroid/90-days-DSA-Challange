/**
 * Delegates creation of copies to the objects that are being copied.
 * Only the object itself may know how to correctly copy its state.
 *
 * This pattern is similar to mitotic cell division.
 */

abstract class Animal {
  private String name;
  private int age;

  public Animal(String name, int age) {
    this.name = name;
    this.age = age;
  }

  String getName() {
    return name;
  }
  int getAge() {
    return age;
  }

  public abstract Animal createClone();
}

class Dog extends Animal {
  private String breed;

  public Dog(String name, int age, String breed) {
    super(name, age);
    this.breed = breed;
  }

  @Override
  public Animal createClone() {
    return new Dog(getName(), getAge(), breed);
  }
}

// ...other subclasses of animal also implement createClone()

class Main {
  public static void main(String[] args) {
    Animal d = new Dog("Boi", 3, "Labrador");
    System.out.println(d.hashCode());
    System.out.println(d.createClone().hashCode());
    // Animal a = new Animal("Gal", 4);
  }
}
