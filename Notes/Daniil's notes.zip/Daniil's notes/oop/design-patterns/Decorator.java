/**
 * Allows to attach additional behavior to object. Helps with single responsibility principle.
 * This is done via wrapping an initial object in another object.
 *
 * Difference between builder and chain of responsibility:
 * builder: creates an object using multiple method calls, each one adds some functionality to the object, creation has to be finalized
 * decorator: adds some functionality dynamically, creation doesn't have to be finalized, at each step the object is a valid entity
 */

interface Outstream {
  public void write(String data);
}

class ConcreteOutstream implements Outstream {
  @Override
  public void write(String data) {
    System.out.println(data);
  }
}

abstract class OutstreamDecorator implements Outstream {
  protected Outstream inner;
}

class LoggingDecorator extends OutstreamDecorator {
  public LoggingDecorator(Outstream outstream) {
    this.inner = outstream;
  }

  @Override
  public void write(String data) {
    System.out.println("Writing " + data);
    inner.write(data);
  }
}

class SafetyDecorator extends OutstreamDecorator {
  public SafetyDecorator(Outstream outstream) {
    this.inner = outstream;
  }

  @Override
  public void write(String data) {
    if (data.length() < 15) {
      System.out.println("Warning: data is too short");
    }
    inner.write(data);
  }
}

class Main {
  public static void main(String[] args) {
    String data = "blah blah blah";
    Outstream s = new ConcreteOutstream();
    s.write(data);
    s = new LoggingDecorator(s);
    s.write(data);
    s = new SafetyDecorator(s);
    s.write(data);
  }
}
