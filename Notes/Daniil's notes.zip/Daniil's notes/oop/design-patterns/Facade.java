/**
 * Problem: the system is complex enough that the user can't reference it's individual objects easily anymore.
 * Solution: abstract out the systems complexity behind a uniting facade class.
 * 
 * This pattern is handy to break up "god objects".
 * To simplify such bloated objects, it's good to split them into separate objects and a facade that unites them.
 */

class CPU {
  public void execute(byte code) {  }
}

class RAM {
  public byte get(long position) { return -1; }
  public void set(long position, byte value) { }
}

class HardDrive {
  public byte[] read(long position) { return null; }
  public void load(long position, byte[] value) {}
}

// This facade lets us abstract away all other components
class Computer {
  private CPU cpu;
  private RAM ram;
  private HardDrive hardDrive;

  public Computer() {
    this.cpu = new CPU();
    this.ram = new RAM();
    this.hardDrive = new HardDrive();
  }

  public void start() {
    long programCounter = 0x8000;
    while (true) {
      // ...
      byte instruction = ram.get(programCounter);
      cpu.execute(instruction);
      // ...
    }
  }
}
