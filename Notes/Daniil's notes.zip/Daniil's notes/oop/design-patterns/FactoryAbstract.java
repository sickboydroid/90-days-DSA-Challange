/**
 * Allows to create multiple object factories.
 * Each factory has the same functionality as a factory method.
 * This helps to create create objects conditionally using information only available at runtime.
 */

abstract class Enemy {
  public abstract void attack();
}

class EasyEnemy extends Enemy {
  @Override
  public void attack() {
    System.out.println("Weak attack");
  }
}
class HardEnemy extends Enemy {
  @Override
  public void attack() {
    System.out.println("Strong attack");
  }
}
class LegendaryEnemy extends Enemy {
  @Override
  public void attack() {
    System.out.println("One-hit attack");
  }
}

abstract class EnemyFactory {
  public abstract Enemy create();
}

class Level1Factory extends EnemyFactory {
  @Override
  public Enemy create() {
    return (Math.random() < 0.9 ? new EasyEnemy() : new HardEnemy());
  }
}

class Level2Factory extends EnemyFactory {
  @Override
  public Enemy create() {
    return (Math.random() < 0.1 ? new EasyEnemy() : new HardEnemy());
  }
}

class Level3Factory extends EnemyFactory {
  @Override
  public Enemy create() {
    return (Math.random() < 0.5 ? new HardEnemy() : new LegendaryEnemy());
  }
}

class Level {
  private EnemyFactory enemyFactory;

  public Level(EnemyFactory enemyFactory) {
    this.enemyFactory = enemyFactory;
  }

  public void onLoad() {
    for (int i = 0; i < 10; i++) {
      Enemy newEnemy = this.enemyFactory.create();
      newEnemy.attack();
    }
  }
}
