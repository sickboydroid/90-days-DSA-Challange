// Define an abstract iterator for different collections.
// Now, any collection can be accessed using the same iterator interface.

// Most languages have built-in language support for this pattern:
// Java - Iterator -> for (var item : collection)
// JS - Symbol.iterator -> for (const item of collection)
// C++ - begin(), end() -> for (auto const& item : collection)

class IteratorTest {
    public void testIterators() {
        int[] nums = new int[] { 1, 2, 3 };
        for (int num : nums) {
            // Iterate over each collection member; this works for any collection
        }
    }
}
