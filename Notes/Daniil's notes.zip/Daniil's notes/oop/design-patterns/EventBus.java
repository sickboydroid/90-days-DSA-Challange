/**
 * Solves the problem of observing changes of a particular object/objects.
 * Events are published to a single event bus.
 * Handlers are notified when the bus receives an event.
 * 
 * EventBus: N + N.
 * Observer: N x N.
 */
