/**
 * Suppose we have an interface I.
 * Class A doesn't implement I but does the things described in interface I.
 * To use A's functionality, we may create an adapter class that implements I and delegates calls to an instance of A.
 *
 * This pattern is usually used to make 3rd party or legacy code work without modifications.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

interface Logger {
  public void log(String text);
}

// This adapter allows us to log with System.out
class StdioLogger implements Logger {
  @Override
  public void log(String text) {
    System.out.println(text);
  }
}

// This adapter allows us to log to file
class FileLogger implements Logger {
  PrintWriter pw;
  public FileLogger(String filename) throws FileNotFoundException {
    pw = new PrintWriter(new File(""));
  }

  @Override
  public void log(String text) {
    pw.println(text);
  }
}

class Program {
  private Logger logger;

  public Program(Logger logger) {
    this.logger = logger;
  }

  public int doSomeHeavyCalculationAndLogProgress() {
    logger.log("Starting calculation;");
    int result = 0;
    logger.log("Initialized;");
    result += 3;
    logger.log("Intermidiate result: " + result);
    result *= 2;
    logger.log("Finished with result " + result);
    return result;
  }

  public void run() {
    int result = doSomeHeavyCalculationAndLogProgress();
    logger.log("Success");
    logger.log("" + result);
  }
}
