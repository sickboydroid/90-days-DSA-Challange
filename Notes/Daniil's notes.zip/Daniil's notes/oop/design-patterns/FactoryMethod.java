/**
 * Similar to builder.
 * If a constructor is hard to use, we may use a wrapper method.
 * It will call the needed constructor.
 * We may also return an existing object in some cases.
 *
 * Constructor can only create an object of a particular class.
 * Factory method can create an object of a class that belongs to an inheritance chain.
 */

abstract class Cake {}
class SmallCake extends Cake {}
class LargeCake extends Cake {}

class CakeFactory {
  public Cake bake(int size) {
    if (size < 5) {
      return new SmallCake();
    } else {
      return new LargeCake();
    }
  }
}
