/**
 * Allows to create some operation for a family of classes without changing all of the classes that need that operation.
 */

interface JSON {
  public default String stringify(SomeAbstractClass object) {
    return "Unregistered class";
  }
  //
  public String stringify(SomeSuperclass object);
  public String stringify(SomeSubclass object);
  public String stringify(SomeSubclassOfSubclass object);
  public String stringify(SomeClass2 object);
}

// class ConcreteStringifier

abstract class SomeAbstractClass {
  // We only need to add one method at the top of the inheritance chain
  // Subclasses will pick this up and call the matching overloaded method
  public String visit(JSON json) {
    return json.stringify(this);
  }
}

class SomeSuperclass extends SomeAbstractClass {
 // ...
}

class SomeSubclass extends SomeSuperclass {
 // ...
}

class SomeSubclassOfSubclass extends SomeSubclass {
 // ...
}

class SomeClass2 extends SomeSuperclass {
 // ...
}
