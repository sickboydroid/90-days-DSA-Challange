# Object-oriented programming

OOP is a programming methodology based on representing the program as a system of objects.  
Each object belongs to some class.  
Classes form inheritance chain.  

Class is a template for an entity that describes its state (fields) and behavior (methods).  
Object is an entity of a particular class.  

- [Object-oriented programming](#object-oriented-programming)
  - [OOP principles](#oop-principles)
    - [1. Inheritance](#1-inheritance)
    - [2. Polymorphism](#2-polymorphism)
    - [3. Encapsulation](#3-encapsulation)
      - [How is Encapsulation different from Concealment?](#how-is-encapsulation-different-from-concealment)
    - [4. Abstraction](#4-abstraction)
    - [5. Interface](#5-interface)
      - [How is interface different from an abstract class?](#how-is-interface-different-from-an-abstract-class)
  - [Other questions](#other-questions)
    - [What are the pros and cons of OOP?](#what-are-the-pros-and-cons-of-oop)
    - [What is a virtual function?](#what-is-a-virtual-function)
    - [What is inversion of control?](#what-is-inversion-of-control)
      - [What is dependency injection?](#what-is-dependency-injection)
      - [What is service locator?](#what-is-service-locator)
    - [What is a method signature?](#what-is-a-method-signature)
    - [What kinds of object relations exist?](#what-kinds-of-object-relations-exist)

## OOP principles

There are 3-5 OOP principles: inheritance, encapsulation, polymorphism\[, abstraction, interface\].

### 1. Inheritance

Inheritance exists to create class hierarchies. This allows the inheriting classes to reuse the code of the parent (both fields and methods).

Heir is a specialized version of parent. Heir can be used in place of the parent (otherwise we break Liskov Substitution).

Inheritance indicates "is" relation.

### 2. Polymorphism

Polymorphism allows to create a single interface for entities of different classes.

Basically, an object of subclass can be put in a variable of superclass.

Subclass can override superclasses method -> subclass can do everything that superclass can, but more / a bit differently.

### 3. Encapsulation

Encapsulation separates object into a public interface and a private implementation.

Private implementation conceals data and methods working on that data.

Encapsulation is a protective shell that simplifies the code for the user and stops the code from being used inapropriately.

#### How is Encapsulation different from Concealment?

Data can be concealed in a lot of different ways (e.g. modules, function code).

Encapsulation is only related to objects, their fields and their methods.

### 4. Abstraction

Abstraction only represents properties of the object which are important for the task.

### 5. Interface

Allows to mark that a class is capable of certain behavior.

#### How is interface different from an abstract class?

Idea:

- Abstract class exists as a backbone of an inheritance chain. It is a template for concrete classes.
- Interface only marks that a class that implements it is capable of some behavior.

Technical value:

- Methods and data of an abstract class can be used by overriding classes.
- An interface only defines functionality.

Consequences:

- Class may impelement multiple interfaces (a class may have multiple behaviors).
- Concrete class may only implement one abstract class since relation "is" is singular.

## Other questions

### What are the pros and cons of OOP?

Gist: OOP is only good for certain kinds of problems.

Pros:

1. Object-oriented code is more reusable.
2. Everyone knows how to write OO code => new developers may be added quickly.
3. The good patterns are already known since it's been used so much.

Cons:

1. More effort to create abstraction chains.
2. Longer and slower code.
3. Inheritance is flawed, composition is better.
4. Internal state of objects is complex.

### What is a virtual function?

Virtual function is a method that can be overridden in subclass.

### What is inversion of control?

Traditional control flow: our code controls the flow (calls methods that it needs).

IOC: our code only provides handlers for events that are used by a framework that dispatches them.  
As a result, the main flow is controlled by the framework.  

Helps achieve [modularity](<../general/general.md#coupling-cohesion-modularity>).

Example GO4 patterns: strategy, template method.

#### What is dependency injection?

If an object relies on some other objects, it receives them instead of creating new instances.

Separates construction and usage of objects.

#### What is service locator?

Service locator is an abstract registry of services.

When some objects needs a service, it gets it from the service locator without knowing any details of that service.

Example: [azure pipelines agent HostContext class](https://github.com/microsoft/azure-pipelines-agent/blob/ceb7d6cb16b0460c38fbb14c65a85f313cc8e88b/src/Microsoft.VisualStudio.Services.Agent/HostContext.cs#L468).

Considered an antipattern by some:

- Makes dependencies harder to find.
- Makes components less testable.

### What is a method signature?

Signature is a sum of access modifier, method name, types of parameters, return type.

It distinguishes this method from others so that there is no ambiguity when it's called.

### What kinds of object relations exist?

- Inheritance: a class IS parent / specialized version of parent.
- Aggregation: class is a container for other classes which may exist independently from the container.
- Composition: same as aggregation, but nested classes may not exist outside of container.
- Association: object A is using object B; if B changes, A needs to change, but not the other way around.
