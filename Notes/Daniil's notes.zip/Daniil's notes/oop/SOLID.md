# SOLID principles.

A collection of object-oriented design guidelines by Robert Martin.

## 1. Single responsibility.

Each object should only have one role in the program.

Antipattern: "god objects" - objects that know and handle everything on their own.

With program's growth these objects quickly become bloated and start to resist changes.

## 2. Open-closed.

Classes, modules, functions etc. should be "open for extension, but closed for modification".

### Interpretation 1.

Class is sealed for modification, but can be inherited from to add new features.

### Interpretation 2.

Similar to strategy: avoid checking for exact cases (if/switch), use polymorphism instead (interfaces).

## 3. Liskov substitution.

Functions that use pointers or references to base classes must be able to use objects of derived classes without knowing it.

Derived class should not break any functionality of superclass.

## 4. Interface segregation.

Clients should not be forced to depend upon interfaces that they do not use.

This principle exists to prevent interface pollution (programmer is forced to implement interface methods that won't be used).

Such interfaces should be broken to concrete behaviors (1-2 methods per interface).

## 5. Dependency inversion.

1. High-level module's code should not depend on low-level module's code, use abstraction (interface) instead.
2. Abstractions should not depend on details. Details should depend on abstractions.
