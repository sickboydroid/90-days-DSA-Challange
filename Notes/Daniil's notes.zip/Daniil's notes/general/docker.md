# Docker

Docker is a containerization tool.

It packages software environment to be run on different operating systems.

Containers reuse the system kernel.

## Basic units of Docker

- Dockerfile: template for images. Includes build and running steps.
- Image: template for containers. Includes cached layers.
- Container: process with containerized executable.

A layer is a snapshot of software. Each instruction of dockerfile creates a new layer.

## Dockerfile instructions

- `FROM <label>`: base image (ubuntu/node/...).
- `WORKDIR <absolute path>`: specifies working directory inside the container.
- `COPY <local path> <container path>`: copy files.
- `RUN <command>`: create a layer from running a command.
- `CMD ["<command>", "<command>", ...]`: final instruction of the dockerfile - runs specified command once the container is ready.

## Practices

Copy and install dependencies before copying the source code (since the latter updates more frequently, and we want the caching benefits).

Build containers as microservices - one process per container. If you need multiple processes, use docker-compose/kubernetes/etc.

## CLI commands

- `docker ps`
- `docker kill <container id(s)>`
- `docker build <path> <image label>`
- `docker run <image label> -p <host>:<container>`: run image and forward port

## Other

- Docker push/pull are usually used to run containers on multiple devices.
- Volumes are a way to store files in the host OS. They may be shared between containers.
