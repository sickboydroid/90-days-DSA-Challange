# MVC and derivatives.

MV* patterns provide two main benefits:
1. Structure - code is uniform.
2. Separation of concerns - code is loosely coupled.

## MVC

Model - the most independent module responsible for logic and state. Accepts method calls from controller. Creates events for view.

View - handles model representation, updates in response to events.

Controller - accepts user input. Calls model methods to modify state.

User -> Controller -> Model -> View -> User -> ...

Web: User -> View (inputs) -> Controller -> Model -> View (painting) -> User -> ...

## MVP

Presenter - accepts inputs like controller; updates view in response to models events.

Model - same as in MVC, but events are created for presenter.

View - same as in MVC, but change is initiated by the presenter. Much dumber than in MVC.

User -> View -> Presenter -> Model,  
Model -> Presenter -> View -> User,  
...

## MVVM

Similar to MVP, but depends on data binding.

View Model - handles data bindings between the UI and the model.

Difference between presenter and view model: presenter contains a reference to view, view model is referenced by view and only handles events & inputs state.

## HMVC

Hierarchical MVC: a program consists of loosely coupled MVC components.

Good for when the app grows too large for MVC.
