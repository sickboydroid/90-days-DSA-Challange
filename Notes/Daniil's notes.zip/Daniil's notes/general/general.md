# General computer science knowledge

- [General computer science knowledge](#general-computer-science-knowledge)
  - [Какие есть парадигмы программирования?](#какие-есть-парадигмы-программирования)
  - [Какие виды памяти существуют?](#какие-виды-памяти-существуют)
  - [Что такое managed-языки?](#что-такое-managed-языки)
  - [Как могут передаваться аргументы методу?](#как-могут-передаваться-аргументы-методу)
  - [Что такое сборка мусора?](#что-такое-сборка-мусора)
  - [Stack frame](#stack-frame)
  - [Calling convention](#calling-convention)
  - [Что такое RAII?](#что-такое-raii)
  - [Statement vs Expression](#statement-vs-expression)
  - [Higher order function](#higher-order-function)
  - [ORM](#orm)
  - [RPC](#rpc)
  - [Какие существуют виды масштабирования?](#какие-существуют-виды-масштабирования)
  - [Idealized feature implementation.](#idealized-feature-implementation)
  - [Что такое методология разработки?](#что-такое-методология-разработки)
    - [Scrum](#scrum)
  - [Coupling, Cohesion, Modularity](#coupling-cohesion-modularity)

## Какие есть парадигмы программирования?

- Императивные (указывают последовательность действий/промежуточных состояний системы):
  - Процедурное программирование: единица кода - процедура; данные - простые или структуры.
  - Объектно-ориентированное программирование (надстройка над процедурным): единица кода - объект.
- Декларативные (указывают желаемый результат, но не как его достичь):
  - Функциональное программирование: единица кода - функция; функции не имеют побочных эффектов и являются чистыми (если одинаковые аргументы, то всегда будет одинаковый результат); состояние хранится в стеке исполнения функций.

## Какие виды памяти существуют?

Существует stack- и heap- память; отличаются тем, как получают доступ к содержимому:
- Stack: память выделяется линейно, доступ только к текущему FIFO stack frame.
- Heap: доступ к объектам может быть из любой части программы при наличии ссылки.

## Что такое managed-языки?

Managed = garbage collected, языки со сборкой мусора (C#, Java); противоположность - unmanaged-языки, вроде C++.

## Как могут передаваться аргументы методу?

По значению - примитивные типы; в C++/C# структуры и объекты; передаваемый объект полностью копируется, изменения скопированного объекта не влияют на переданный.

По ссылке - объекты; в C#/C++ указатели на примитивы; в функцию передаётся ссылка на объект, его изменение изменяет передаваемый объект.

## Что такое сборка мусора?

Сборка мусора (garbage collection) - процесс освобождения неиспользуемых объектов heap-памяти

Механизмы поиска неиспользуемых объектов:
1. Reference counting - подсчитываем во время исполнения программы количество ссылок (аргументы, переменные, поля классов итд), ведущих на объект; если количество ссылок НА (исходящие из объекта ссылки не влияют) какой-то объект станет равным нулю, то мы уже никак не сможем получить к нему доступ из какой-либо части программы -> можно очищать.
2. Tracing - подсчёт ссылок сталкивается с проблемой в круговых структурах данных в памяти: объекты могут ссылаться друг на друга, но на них никакие другие объекты не ссылаются -> объектов нельзя достичь, но количество входящих ссылок не равно 0; чтобы удалить такие объекты, используется tracing: из корней сборки мусора (GC roots) проходим по графу ссылок; объекты, до которых мы не дошли, можно очистить из памяти.

GC roots в JavaScript:
1. Скоупы
2. Таблица символов
...итд

## Stack frame

Стековый фрейм - это область памяти, выделяемая при вызове функции; в нём хранятся её параметры, переменные, и адрес возврата.

## Calling convention

Calling convention defines a template for low-level function calls.

## Что такое RAII?

RAII (resource acquisition is initialization) - принцип программирования, при котором получение ресурса связано с созданием объекта, а его освобождение - с уничтожением объекта.

Наиболее применимо к C++, в котором получение ресура можно делать в конструкторе, а освобождение - в деструкторе.

## Statement vs Expression

Statement only executes some action.

Expression creates a new value. Expression is a statement as well.

## Higher order function

Is a function that performs operations on other functions - takes them as arguments or returns them.

## ORM

- ORM is a technique of mapping the database types to type systems of a programming language.
- ORMs allow to manipulate data via programming language constructions, without low-level operations with the database.

## RPC

Remote Procedure Call is when a program causes a procedure to run on a different machine.

## Какие существуют виды масштабирования?

- вертикальное масштабирование: добавить мощность к текущему железу; со временем понижается соотношение цена/качество
- горизонтальное масштабирование: добавить ещё железо; со временем возрастает сложность поддержки

## Idealized feature implementation.

1. Feature - MVP, quick and dirty code.
2. Refactoring according to usage experience.
3. Documentation.
4. Fixes.

## Что такое методология разработки?

Методология разработки - это описание того, как реализуется определённый программный продукт.

Постановка и разбиение задач, цикл разработки.

### Scrum

Key features:
- Development cycle consists of sprints.
- Daily syncs with progress.
- Retro sync at the end of the sprint.

## Coupling, Cohesion, Modularity

Coupling is the degree to which some set of objects is connected to the other objects in that set.  
Loose coupling means there is little concrete connection, only interfaces.  

Cohesion is the degree to which interfaces of a set of objects belong with each other/fit each other.  
High cohesion means objects are grouped by their meaning and these groups are clearly separated.  

Loose coupling is corellated with high cohesion.  
Both result in high code modularity.  

Modularity advantages:
- Testability
- Reusability
- Maintainability (changes in one object lead to little changes in another)
- Replaceability
- Reduced complexity
