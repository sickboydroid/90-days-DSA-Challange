## Compiler frontend and backend

Usually, the compiler is divided into two parts:
- Frontend - scanning, parsing, semantic checker
- Backend - code generation

Both can include optimization steps

This separation is done since there is usually one frontend and many backends, each one for a separate environment.
It also helps when there are multiple frontends, since all of them may use the same set of backends.
N * M problem turns into a N + M problem.

## IR optimizations

A set of simple optimizations can lead to complex optimizations if done in multiple passes.
These optimizations are applied until there are no more optimizations to be made.
