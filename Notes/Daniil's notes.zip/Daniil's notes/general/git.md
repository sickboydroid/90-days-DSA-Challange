# Git

## What is a version control system?

VCS is software that tracks, synchronizes and stores code changes.

Allows developers to work on different parts of the code and merge their changes later.

## Workspace, INDEX, HEAD, remote

Workspace is the real state of the files.

INDEX is the staged (proposed) changes for the next commit.

HEAD is the active commit (current branch) in local repository.

### Data transfer commands

Forward:
- Workspace to INDEX: `git add`
- INDEX to HEAD: `git commit`
- HEAD to remote: `git push`

Backward:
- Remote to HEAD: `git fetch`
- HEAD to workspace: `git checkout <commit>`

### Moving HEAD

- `git reset --soft`: only moves the head
- `git reset --mixed` (default): moves the head and resets INDEX, but leaves workspace unchanged
- `git reset --hard`: moves the head and resets INDEX and workspace to the commit state, discarding all the changes

## Git merge vs rebase

### Merge

`git merge <feature-branch>` - includes all commits from feature to current branch and sews them together into one commit.

Stores all of the commits of the feature branch, and creates one additional commit for resolving conflicts.

### Rebase

`git rebase <trunk-branch>` - repeates all commits from current branch (feature) on top of target (trunk).

Rebase stores all commits of the feature branch, but conflicts will have to be resolved for each commit.
