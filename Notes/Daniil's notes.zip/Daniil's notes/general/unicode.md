# Unicode

Unicode is a format of encoding any characters.

## Unicode structure

- Grapheme is a smallest inseparable symbol of natural language (letter, hieroglyph, emoji, etc.). Consist of code points.
- Code point is a numerical value that maps to a character or its part (or a control character/...).
- Bytes of code points may be encoded differently: UTF-32, UTF-16, UTF-8 (most common), etc.

## UTF-8 strengths compared to UTF-16+

UTF-8:
- Maps directly to ASCII.
- Requires less space than other encodings.
- Number of bytes for code points is different, and most common graphemes (english/control characters) only require a single byte to represent.
