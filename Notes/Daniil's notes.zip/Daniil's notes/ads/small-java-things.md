left/right shift have lower precedence compared to other mathematical operations, e.g.
`a << 10 + b` is the same as `a << (10 + b)`

Whenever we need to sort two separate arrays which have connected elements, sort indices instead.
