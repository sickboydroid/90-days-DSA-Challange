Arrays are 50x-100x faster than linked lists in almost all tasks.
Even if we have to shift the elements array wins because of cache.

"Pointers are poison to most optimizers".
