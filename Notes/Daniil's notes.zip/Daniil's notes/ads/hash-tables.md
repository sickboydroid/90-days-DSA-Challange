# Hash table

| Action | Time |
| ------ | ---- |
| Insert | O(1) |
| Search | O(1) |
| Delete | O(1) |

## Implementation details

Hash table internally is an array of size `m`.  

Prehashing: generates a random number, potentially larger than the table size.  
Hashing: squishes the prehash value to range `[0, m - 1]`.  

`a = n / m`, where `n` is the amount of items.  
`a` should be < 1 for O(n) time complexity.  
`a = 0.75` is a good trade-off.  

Collision resolution: chaining - linked list for each key hash.  
Other data structures can be used too.  

Good hash function: `h(k) = [(a * k) mod 2^w] >> (w - r)`, where  
`w` is the bitness of the machine  
`a` is a random `w`-bit value  
`k` is the prehash value  
`r` as a power of 2 is the size of the table, so `m = 2^r`  

Multiplication is adding random shifts;
`mod 2^w` takes the last word;
right-shifting `w - r` bits leaves the first `r` bits, which are "most random" (last bits are more likely to match the original number k).

## Table doubling

If `n` reaches `m`, we can make `m = 2 * m` and add all existing items to the new table.  
If `n` reaches `m / 4`, we can make `m = m / 2` and add all existing items to the new table.  

Even though rehashing all values is `O(N)`, we do it rarely enough that on average all operations are `O(1)`. This is called **amortized time complexity**.  

## Instant upload trick (dropbox, google drive)

For each file, store 3-5 hashes from different hash functions.
Calculate hashes locally, send them to the server.
If there is a match, then it's most likely the same file.

## Distributed hash table

Table is distributed between many computers.
They can be thought of as located on a circle.
Computers to the left and right of some computer store copies of it's data.
If any computer breaks, computers to the right and to the left will take it's load.
If a new computer is added to the circle, it copies data from the left and from the right.
