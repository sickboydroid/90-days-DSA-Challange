Merkle hashing of a binary tree: hash of a node consists of hashes of it's left and right children and it's value

Example: 
https://leetcode.com/submissions/detail/589562451/
