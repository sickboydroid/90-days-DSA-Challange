# Binary search

Time: O(logN)  
Space: O(1)  

This algorithm may also be used to find the index at which to insert a certain element if it's missing.  

Implementation:  
```js
function binarySearch(nums, target, start, end) {
  let l = start;
  let r = end; // Inclusive

  while (l <= r) {
    const m = (l + r) >>> 1;

    if (nums[m] < target) {
      l = m + 1;
    } else if (nums[m] > target) {
      r = m - 1;
    } else {
      return m;
    }
  }

  // l is now the insertion point; make it negative to mark it
  // subtract 1 in case l === 0
  return -(l + 1);
}
```

Good way to avoid integer overflow when getting middle of the list:  
`m = l + (r - l) / 2`;  
