# Graphs

## Definition

A graph G = (V, E) is defined by a set of vertices V and a set of edges E

## Variations

Undirected graph: if some edge (x, y) is in E, then (y, x) is also in E
Directed graph: if some edge (x, y) is in E, then (y, x) may not be in E

Weighted graph: each edge or vertex is assigned some weight

Acyclic graph: no cycles. DAG = directed acyclic graph

## Data structures for graphs

There are two main data structures to represent graphs:
- Adjacency matrix - a 2D array of size |V| by |V|
- Adjacency list - an array of size |V| containing lists with pointers to connected vertices

## Graph algorithms

### BFS

BFS is good for finding shortest paths and finding connected components

```
Initialize boolean[] discovered
Initialize a queue, add the search start to it
while the queue is not empty:
  take the next element
  for each connection to other element:
    if other element is discovered:
      skip
    add other element to queue and mark it as discovered
```

### Two-coloring a graph

If a graph can be two-colored such that no adjacent vertices share the same color, it's *bipartite*.

```
bipartite = true

for each vertex:
  if not discovered:
    mark with the first color
    bfs

bfs processes the edges in a way that the current element should have the opposite color compared to the previous one.
If current element already has a color and it's the same as the color of the previous element, set bipartite to false.
```

### Topological sorting

Essence: for each edge A -> B, A's index is before B.

Kahn's algorithm can put nodes in order.

```
result = []
queue = [...nodesWithNoIncomingEdge]
connections = { from: to }
numberOfIncomingConnections = { to: amount }

while !queue.isEmpty():
  from = queue.poll()
  result.add(from)
  for each to in connections[from]:
    if numberOfIncomingConnections[to] == 0:
      queue.add(to)
```

## Sources

Skiena Lectures:
- [CSE373 2012 - Lecture 11 - Graph Data Structures (video)](https://www.youtube.com/watch?v=OiXxhDrFruw&list=PLOtl7M3yp-DV69F32zdK7YJcNXpTunF2b&index=11)
- [CSE373 2012 - Lecture 12 - Breadth-First Search (video)](https://www.youtube.com/watch?v=g5vF8jscteo&list=PLOtl7M3yp-DV69F32zdK7YJcNXpTunF2b&index=12)
- [CSE373 2012 - Lecture 13 - Graph Algorithms (video)](https://www.youtube.com/watch?v=S23W6eTcqdY&list=PLOtl7M3yp-DV69F32zdK7YJcNXpTunF2b&index=13)
- [CSE373 2012 - Lecture 14 - Graph Algorithms (con't) (video)](https://www.youtube.com/watch?v=WitPBKGV0HY&index=14&list=PLOtl7M3yp-DV69F32zdK7YJcNXpTunF2b)
- [CSE373 2012 - Lecture 15 - Graph Algorithms (con't 2) (video)](https://www.youtube.com/watch?v=ia1L30l7OIg&index=15&list=PLOtl7M3yp-DV69F32zdK7YJcNXpTunF2b)
- [CSE373 2012 - Lecture 16 - Graph Algorithms (con't 3) (video)](https://www.youtube.com/watch?v=jgDOQq6iWy8&index=16&list=PLOtl7M3yp-DV69F32zdK7YJcNXpTunF2b)
