StringBuffer is faster than creating new strings

```
var b = new StringBuffer();
b.append('c');
b.deleteCharAt(result.length() - 1);
```

Using char[] is even faster, but only viable when we know the length of the final string

Converting String to char array grants faster element access compared to charAt()

```
char[] chars = string.toCharArray();
chars[i] = 'e';
String result = new String(chars);
```
