# Heap

Heap is an array visualized as a nearly-complete binary tree.

Max-heap property: the key of a node is >= the keys of its children

## Operations

`maxHeapify` (`siftDown`) - correct a single violation of the heap property in a subtree's root.
Assumes left and right subtrees are correct heaps. O(log(n))

`buildHeap` - produce a max heap from an unsorted array.
Time complexity is O(n) because as you get higher the number of operations increases, but the number of node decreases.

These two operations are enough to create a max heap.

`siftUp` is needed to add a new item - its called after pushing the item to the end of the array.  
The function compares this item with its parent and swaps if its larger. Then repeat for parent (which is now item). Stop if parent is larger.

## Heap sort

Algorithm for sorting an array using max heap:
1. Build a heap from a given array.
2. Swap the first element with the last one, and decrease heap size by 1.
3. The new first element may violate the heap property, so heapify it down.
4. Go to step 2 until there is one node left

The result is a sorted array.

## Source

[MIT lecture about Heaps and Heap Sort](https://www.youtube.com/watch?v=B7hVxCmfPtM)
[Source code](https://github.com/qucumbah/prep_java/blob/main/prep/heap/MaxHeap.java)
