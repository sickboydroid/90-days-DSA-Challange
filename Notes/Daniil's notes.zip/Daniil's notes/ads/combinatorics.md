## Factorial

If we have `n` objects, then there are `n!` ways to arrange them:

```
n = 4;
ways = 4 * 3 * 2 * 1; // 4 options for the first position, 3 options for the second, etc.
```

## Permute

If we need to pick `r` objects from a collection of size `n` and the order matters, then there are `n!/(n - r)!` ways to do that:

```
n = 10;
r = 4;
nPr = 10 * 9 * 8 * 7; // 10 options for the first position, 9 options for the second, etc.
```

## Combine

If we need to pick `r` objects from a collection of size `n` and the order does not matter, then there are `n!/((n - r)! * r!)` ways to do that:

```
n = 10;
r = 4;
nPr = 10 * 9 * 8 * 7; // 10 options for the first position, 9 options for the second, etc.
nCr = nPr / (4 * 3 * 2 * 1) // For each set of size 4, there are 4! ways to arrange the items
```
