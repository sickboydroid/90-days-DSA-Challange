Task: find a small string `s` in a text `t`.

Naive implementation would in worst case be `O(|s| * |t|)`

We can hash all matches of length `|s|` in `t` using a sliding window. But we still have the same time complexity since hashing will require `O(|s|)` time.

This is why we have to use **rolling hash**. When we move our sliding window we only remove one letter and add one letter, so we can change our hash depending on those letters. This hashing method will be `O(1)`, which means that search will be `O(|t + s|)`.
