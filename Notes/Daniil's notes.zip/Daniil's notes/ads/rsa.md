## RSA

Encryption key is public.

Decryption key is secret.

Use case 1 - sending an encrypted message (256 bytes max, usually used to pass symmetric algorithm key):
1. Receiver exposes public key
2. Sender uses the public key to encrypt a message
3. Receiver decrypts the message with a secret key

Use case 2 - signing a message (usually used to sign messages hash):
1. Sender calculates message hash
2. Sender signs the message hash with their private key
3. Sender sends the message with signed hash
4. Receiver gets messages hash by decrypting it with senders public key
5. Receiver compares calculated and received hashses to verify
