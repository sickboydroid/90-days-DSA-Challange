# Knuth-Morris-Pratt (KMP for shorthand)

Algorithm for substring matching that works in O(N + M) time and O(M) space

## Implementation

```java
class Solution {
  public int strStr(String haystack, String needle) {
    if (needle.length() == 0) {
      return 0;
    }

    if (needle.length() > haystack.length()) {
      return -1;
    }

    int[] prefixes = getPrefixArray(needle);

    int i = 0;
    int j = 0;
    while (i < haystack.length()) {
      if (haystack.charAt(i) == needle.charAt(j)) {
        i += 1;
        j += 1;
      } else {
        if (j == 0) {
          i += 1;
        } else {
          j = prefixes[j - 1];
        }
      }

      if (j == needle.length()) {
        return i - j;
      }
    }

    return -1;
  }

  private int[] getPrefixArray(String pattern) {
    int[] prefixes = new int[pattern.length()];

    int l = 0;
    int r = 1;
    while (r < pattern.length()) {
      if (pattern.charAt(l) == pattern.charAt(r)) {
        prefixes[r] = l + 1;

        l += 1;
        r += 1;
      } else {
        if (l == 0) {
          r += 1;
        } else {
          l = prefixes[l - 1];
        }
      }
    }

    return prefixes;
  }
}
```

## Explanation

Find small `pattern` in a large `text`

Preparation: calculate every suffix that is also a prefix in `pattern`.
Time: O(|pattern|)
Space: O(|pattern|)

Algorithm: go through every letter of text and pattern;
if there is a mismatch, look at the prefix array and find where the search could start from.
Time: O(|text|)
Space: O(1)

## Video explanation

The algorithm is hard to describe in words; here's an overview based on concrete examples:
https://www.youtube.com/watch?v=GTJr8OvyEVQ
