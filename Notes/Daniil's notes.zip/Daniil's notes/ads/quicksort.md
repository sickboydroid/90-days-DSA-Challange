# Quicksort

Time: O(N^2)  
Space: O(1)  

## Algorithm

Partition the elements into two groups.  
Perform the same partition recursively to the left and the right parts.  
Stop when group size is <= 1.  

Partition: choose an element (pivot);  
reorder the array elements so that:  
- all elements less then the pivot are to the left of it
- all elements greater then the pivot are to the right of it
- all elements equal to the pivot can be on either side

Hoare partition:
```java
private int partition(T[] array, int l, int r) {
  T pivot = array[(l + r) / 2];

  while (true) {
    while (array[l].compareTo(pivot) < 0) {
      l += 1;
    }

    // Everything to the right of r is guaranteed to be >= pivot
    while (array[r].compareTo(pivot) > 0) {
      r -= 1;
    }

    if (l >= r) {
      return r;
    }

    T temp = array[l];
    array[l] = array[r];
    array[r] = temp;

    l += 1;
    r -= 1;
  }
}
```

## Quickselect

A partial version of quicksort can be used to effectively solve "N most" type of problems.  

Partition the elements, check how many are on each side.  
Continue partitioning until the right number of elements is to the right or to the left of the partition point.  
