# Kadane's algorithm

## Code

If there may be an empty subarray:
```java
int max = 0;
int cur = 0;
for (int i = 0; i < arr.length; i += 1) {
  cur = Math.max(0, cur + arr[i]);
  max = Math.max(max, cur);
}

return max;
```

If there may not be an empty subarray:
```java
int max = Integer.MIN_VALUE;
int cur = 0;
for (int i = 0; i < arr.length; i += 1) {
  cur = Math.max(arr[i], cur + arr[i]);
  max = Math.max(max, cur);
}

return max;
```

## Main idea
At step `i`, `cur` is the greatest possible sum of elements up to `cur`.

## Proof through contradiction:
Suppose we have an array of some elements, and we have picked a number of elements for step cur:
```
[0, 1, 2, 3, 4, 5, 6] // Indices
[*, *, *, *, *, *, *] // Elements
      [p, p, p]       // Chosen elements (we have reset the current sum at the start of this array)
```

At step `i == 2` we have reset the `cur` sum value, which means that the current sum at point 1 should have been negative.  
Let's suppose we have a better subarray. There are four possible cases:
1. Skip `arr[2]` that is negative. This is impossible since the algorithm wouldn't have picked it as the first item.
2. Skip `arr[2]` that is positive.
  1. If `arr[2]` is followed by only positive or small negative numbers, then removing it would only decrease the sum.
  2. If `arr[3]` is a negative number such that `|arr[2]| < |arr[3]|`, then we would have picked a later item as the subarray start.
3. Add `arr[1]` that is positive. This is impossible since the algorithm would have picked it as the first item.
4. Add `arr[1]` that is negative.
  1. If `arr[1]` is preceded by only negative or small positive numbers, then adding it would only decrease the sum.
  2. If `arr[0]` is a positive number such that `|arr[0]| > |arr[1]|`, then we would have picked it or a preceding item as the subarray start.

## Links

Leetcode problem: https://leetcode.com/problems/maximum-subarray/
Info: https://en.wikipedia.org/wiki/Maximum_subarray_problem
