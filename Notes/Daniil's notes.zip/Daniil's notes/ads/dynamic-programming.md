Mostly used to count a number of ways to do something

Store information about each state (e.g. in array), e.g.:
A hopper can jump 1 or 2 steps. How many ways is there to get to step 5?

If state is multi-dimensional, we may have multi-dimensional arrays.
Example: modified task: how many ways to get to step 5 with at most 3 jumps?
Need to store info about the number of jumps.

Backward (regular) DP:
```java
int[] numberOfWays = ...;
for (int i = 2; i < N; i += 1) {
  numberOfWays[i] = numberOfWays[i - 1] + numberOfWays[i - 2];
}
```

Forward DP:
```java
int[] numberOfWays = ...;
for (int i = 0; i < N - 2; i += 1) {
  numberOfWays[i + 1] += numberOfWays[i];
  numberOfWays[i + 2] += numberOfWays[i];
}
```

If there are multiple dimensions of state, we have to use multi-dimensional DP array  
Sometimes multiple dimensions of state may be converted to a single dimension. Look at the state transitions. Example:
Before: https://leetcode.com/submissions/detail/582828383/  
After:  https://leetcode.com/submissions/detail/582832965/  

Along with minimum/maximum number of something you may store additional info in another array,
e.g. info about array index where that min/max came from.
Example: https://leetcode.com/submissions/detail/587727415/

Main points:
- Think "What is important so far"
- Avoid double counting
