# Bit manipulation

## Bit negation trick

Negating the number is flipping the bits and adding 1:
a = -a  
<===>  
a = ~a + 1  

Example:  
0000 0101 == 5  
1111 1011 == -5  

This is useful for finding Hamming weight

## Iterative bit flipping

Go through all numbers; flip bits in a buffer/buffers to find the resulting number

Example: https://leetcode.com/problems/single-number-ii/
