# Leetcode problem solving log

This is a list of solved leetcode problems.

For each problem, you should write down the solution(s) and what issues you've faced while solving it.

- [Leetcode problem solving log](#leetcode-problem-solving-log)
  - [TODO](#todo)
  - [01 Matrix](#01-matrix)
  - [3Sum](#3sum)
  - [Accounts merge](#accounts-merge)
  - [Binary tree right side view](#binary-tree-right-side-view)
  - [Construct binary tree from preorder and inorder traversal](#construct-binary-tree-from-preorder-and-inorder-traversal)
  - [K closest points to origin](#k-closest-points-to-origin)
  - [Lowest common ancestor of a binary tree](#lowest-common-ancestor-of-a-binary-tree)
  - [Majority element](#majority-element)
  - [Merge intervals](#merge-intervals)
  - [Minimum height trees](#minimum-height-trees)
  - [Partition equal subset sum](#partition-equal-subset-sum)
  - [Single number II](#single-number-ii)
  - [Word break](#word-break)
  - [Subsets](#subsets)

## TODO

Todos:
- https://leetcode.com/problems/lru-cache/
- https://leetcode.com/problems/two-sum-ii-input-array-is-sorted/ - double pointer range shrinking
- https://leetcode.com/problems/subsets-ii/ - helpful bitmask visualisation; also check 0ms submission: good backtracking practice
- https://leetcode.com/problems/subarray-product-less-than-k/ - sliding window tricks
- https://leetcode.com/problems/permutations-ii/ - avoid duplicates without memorizing them
- https://leetcode.com/problems/largest-component-size-by-common-factor/ - union find application; number factorization
- https://leetcode.com/problems/word-search-ii/ - tries
- https://leetcode.com/problems/word-ladder/
- https://leetcode.com/problems/merge-k-sorted-lists/
- https://leetcode.com/problems/regular-expression-matching/

## [01 Matrix](https://leetcode.com/problems/01-matrix/)

Solution 1: BFS starting from zeroes.

Solution 2: DP: closest way from the top/left, closest way from bottom/right, pick closest.

## [3Sum](https://leetcode.com/problems/3sum/)

Solution 1:

For each point, find the value to the left of it by converging two pointers.

Time: O(N^2).

Solution 2:

Split the numbers into the negatives, positives, and zeroes.
Calculate the number of solutions:
- Three zeroes.
- Negative, zero, positive.
- Negative, negative, positive.
- Negative, positive, positive.

Time: O(N^2).

This one is rough, probably best to split the search for all solutions into separate loops.

## [Accounts merge](https://leetcode.com/problems/accounts-merge/)

Union find of graph of accounts where connections are equal emails.

## [Binary tree right side view](https://leetcode.com/problems/binary-tree-right-side-view/)

Single-pass algorithm: always look at the rightmost node first, keep track of current level.  
If it's equal to result length, add it to the result - this is the rightmost node at this level.  

## [Construct binary tree from preorder and inorder traversal](https://leetcode.com/problems/construct-binary-tree-from-preorder-and-inorder-traversal/)

Save positions of all inorder elements in a hash map.  
At each index I of preorder: everything to the left of it in inorder is the left subtree, everything to the right is the right subtree.  
Proceed recursively, mark the left and right boundaries of trees.  
Number of elements in the left subtree can be calculated as a difference between current element's position in the inorder and the left boundary.  

## [K closest points to origin](https://leetcode.com/problems/k-closest-points-to-origin/)

Solution 1:

Add elements to a max (in terms of distance) heap. If the size of the heap is > k, remove first item.

Time: O(n * log(k)).
Space: O(k).

In practice, heap of size N works faster.

Solution 2:

Quickselect.

Time: O(n). // QuickSelect is quicksort where we only handle one side

## [Lowest common ancestor of a binary tree](https://leetcode.com/problems/lowest-common-ancestor-of-a-binary-tree/)

If node == q || node == p return node - either p or q are ancestors of one another, or we're inside a branch that starts at the common ancestor.  
Recursively find left and right. If both are not null, return current node. Else return the one that is not null. Else return null.  

## [Majority element](https://leetcode.com/problems/majority-element/)

Solution 1: sorting.

Solution 2: bit counting: if an element appears >= n/2 times, its bits are going to dominate.

## [Merge intervals](https://leetcode.com/problems/merge-intervals/)

Solution 1:

Sort elements by starts, go through each element and see if it overlaps with the current buffer's one.

Solution 1:

Create two arrays: starts and ends. Increment `starts[intervals[i][0]]`, same with ends. Keep track of balance, create new interval if it becomes 1, push if it becomes 0.

## [Minimum height trees](https://leetcode.com/problems/minimum-height-trees/)

Find current leaves of the tree.
Loop: remove current leaves (while finding the new ones), remove them. Don't forget about cases where two leaves point at each other.
Once there is nothing to remove, the last set of leaves was the set of origins.

## [Partition equal subset sum](https://leetcode.com/problems/partition-equal-subset-sum/)

Solution 1:

Store possible sums in a set. For each number * for each sum, add sum + number to the set. Succeed if the result is total / 2.

Solution 2:

Classical knapsack problem solution.  
DP: iterate over each num and each possible sum.  
Step 1: 2D with dimensions `[sum]` and `[number of items picked]`.  
Step 2: 1D with `[whether this sum is possible]`. We can't get the `sum === total / 2` with all items, so we only have to check for ability to reach it.  

## [Single number II](https://leetcode.com/problems/single-number-ii/)

Store current bits state in two buffers.  
Find out bitwise formulas that update that bit state depending on the incoming 1 bits.  
Example formulas:  
```java
// a == met a single time
// b == met twice
int newa = (~n & a) | (n & ~a & ~b); // a will stay the same if n == 0; otherwise, it will only be 1 if both a and b are 0
int newb = (~n & b) | (n & a & ~b); //  b will stay the same if n == 0; otherwise, it will only be 1 if a is 1 and b is 0
```

## [Word break](https://leetcode.com/problems/word-break/)

Solution 1:

DP: iterate a pointer over the length of the string. At each step, look at every word of the dictionary. Check its length. If `dp[i - len]` and the `word == string.slice(i - len, i)`, `dp[i] = true`.

Solution 2:

Upgraded DP: store possible lengths in a separate hash set. If `dp[i - possibleLen]` get a slice and look for it in the dictionary.

Solution 3:

Trie optimization of DP. Figure out on your own.

## [Subsets](https://leetcode.com/problems/subsets/)

Solution 1:

Recursion with two possible options: either add `number[i]`, or don't. After, make a recursive call with increased index.

Solution 2:

Bitmasks - iterate over 2^N possible options, for each one there is a unique subset where 0 means don't take, 1 means do.

## [Find median from data stream](https://leetcode.com/problems/find-median-from-data-stream/)

Keep two priority queues: one for small items (max heap), one for large ones (min heap).

Add element to large queue. If large queues length is larger than small ones by 2, extract min from it and add to small items queue.

The median is either the overflowing element, or the average of two extracted elements.
