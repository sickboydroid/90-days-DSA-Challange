# Information sources

## System design primer

A guide on designing large-scale systems.

https://github.com/donnemartin/system-design-primer
