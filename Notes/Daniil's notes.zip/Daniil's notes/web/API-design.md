# APIs

API is a contract of communication with a service.

The purpose of the API is to hide the internal details of the system and only expose useful data.

API can be viewed as a library (set of functions).

## API documentation.

- Categories of information returned by the API are called "Resources".
- Resources have various endpoints to access the resource and multiple methods for each endpoint.

Don't over-document your APIs. They shouldn't be user guides, but rather quick references.

## API paths.

Example API path: `/surfreport/{beachId}?days=3&units=metric&time=1400`.
`beachId` is a path parameter, `days` and the following ones are query parameters.
You may also use request bodies.

## API design principles.

- Avoid taking additional parameters unless absolutely necessary (optimization).
- Don't define too many errors for invalid usage - if user breaks the contract, the request can be failed.
- Action should be defined in the API path, not in the provided parameters.
