# Security

## OWASP

Open Web Application Security Project provides lists of the most dangerous vulnerabilities on the web.

### Broken access control

Allows users to bypass access limitations.

Defences:
- Deny access by default
- Configure CORS
- Don't allow client state to determine permissions

### Cryptographic failures

Happens when data is poorly/not encrypted.

Defences:
- Modern safe protocols (https, smtps, ...)
- Modern encryption methods
- Strong passwords with salting

### Injection

Happens when user data is not sanitized.

Defenses:
- Modern APIs instead of string interpolation
- Server-side input validation
- Don't use `eval` or `innerHTML`

### Insecure design

Absense of strong security considerations.

Defences:
- Intergrate security into user stories
- Limit resource consumption

### Security misconfiguration

Defences:
- Regularly checking of all security

### Server-side request forgery

Access to secret resources of the server.

Defences:
- Don't send raw responses to the client
