# Open Systems Interconnection (OSI) model

OSI describes seven layers that computer systems use to communicate over a network.

OSI is most useful as an abstract logical model.

Replaced with a simpler [TCP/IP model](<./TCP-IP-model.md>).
- Levels 5-7 are combined into Application layer of TCP/IP.
- Levels 1-2 are combined into Network Access layer of TCP/IP.

## OSI layers

### 7. Application layer

Provides high-level software protocols (HTTP, FTP, SMTP, DNS, ...).

### 6. Presentational layer

Handles encoding and compression for correct transfer.

### 5. Session layer

Opens sessions between devices, ensures they stay open, closes them.

### 4. Transport layer

1. Breaks data into segments, reassembles them on the receiving end.
2. Handles flow control (match transfer rate to connection speed) and error control (re-request information if it's incorrect).

### 3. Network layer

1. Breaks up segments into packets, reassembles them on the receiving end.
2. Discovers the best path on the physical network.

### 2. Data link layer

Establishes and terminates a connection between two physically-connected nodes on a network.

### 1. Physical layer

Physical cable or wireless connection.
