# Transmission control protocol (TCP/IP) model

TCP/IP is a communication protocol for computer networks.

## TCP/IP Levels

### 4. Application layer

Application-level protocols: HTTP, FTP, SSH and others.

### 3. Transport layer

Provides reliable data transfer (TCP, UDP) to shield layer 4.

### 2. Internet layer

Connects devices across networks using IP addresses.

### 1. Link layer

Physical transmission of data, hardware communication protocols.
