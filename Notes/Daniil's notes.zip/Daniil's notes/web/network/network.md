# Networks.

- [Networks.](#networks)
  - [The internet vs The web.](#the-internet-vs-the-web)
  - [IP protocol.](#ip-protocol)
    - [How are IP addresses allocated?](#how-are-ip-addresses-allocated)
    - [What are packets?](#what-are-packets)
    - [NAT.](#nat)
  - [DNS.](#dns)
  - [Long polling.](#long-polling)

## The internet vs The web.

The internet is a decentralized network of computers addressed with IP.

The web is a hypertext network built on top of the internet. Built on HTTP.

## IP protocol.

IP is a connectionless protocol (like UDP) since packets travel individually and are not guaranteed to come (in order/at all).

In a connection-based protocol like TCP connection is maintained for multiple packets.

### How are IP addresses allocated?

There is a centralized Internet Assigned Numbers Authority for that.

### What are packets?

A packet is the 64kb unit of information that is transferred in the IPv4 protocol.

IPv6 packets are usually 64kb, but may include *jumbograms* up to 4Gib in size.

### NAT.

Network Address Translation converts local network IP addresses into global ones.

Usually works via mapping multiple local IPs to a single global IP with multiple ports.

Benefits:
- Saves the number of IP addresses.
- Hides local network complexity.

## DNS.

Domain Name System translates web addresses into IPs.

DNS has authoritative servers at the top.
ISP has it's own low-level DNS servers that query top-level server.
Your browser makes requests to the ISP's servers.

The results may be cached by the browser or by the ISP.

## Long polling.

Long polling is a regular HTTP request which is supposed to hang until the server responds.

Server has to be OK with lots of parallel hanging connections.

```js
async function longPoll(url) {
  const response = await fetch(url);

  if (response.status === 502) { // Request timeout
    await longPoll(url);
  }

  return response;
}
```
