# HTTP

HTTP is an application-level protocol used as a foundation of the web.

## Uses

Used to transfer generic data (formerly, only hypertext) over the network.

## Version comparison

This lists the new features that appear in the protocol versions.

### HTTP/1.0

- Outdated version

### HTTP/1.1

- Most supported option
- TCP connection reuse (`Connection: keep-alive`)

### HTTP/2

- Allows multiple parallel network requests over a single TCP channel
- Headers are compressed
- Binary protocol
- Uses encryption by default; unencrypted is rarely allowed

### HTTP/3

- Uses faster QUIC, UDP, unlike earlier versions that suffer from TCP overhead
- May not be used without encryption

## HTTPS

HTTPS is an extension of HTTP that is encrypted with TLS (formerly SSL).

Verifies website authority, encrypts passed data, protects against man-in-the-middle attacks.

## HTTP methods

Most common methods are HEAD, GET, POST.

- HEAD: request meta-information
- GET: HEAD + content
- POST: submit some entity to a resource, cause state change on the server
- PUT: replace current content with request payload
- DELETE: delete a resource
- CONNECT: establish a tunnel to the server
- OPTIONS: describe communication options for the target resource
- TRACE: perform message loop-back test, determine path to the resource
- PATCH: apply partial modification to a resource

## HTTP headers

Headers are request/response metadata.

Case-insensitive.

Example headers:
- `Authorization`
- `Cache-Control`
- `Content-Length`
- `Content-Type`
- `Access-Control-Allow-Origin`

## Cross-Origin Request Sharing

CORS is a header-based policy of which requests may be done by the client.

E.g. client uses frontend code from origin A, and the script fetches from origin B.

By default, fetching anything from origin B is restricted, unless CORS headers are present.

## Maximum number of parallel HTTP requests

Most browsers default to a maximum of 6 parallel requests per host.
