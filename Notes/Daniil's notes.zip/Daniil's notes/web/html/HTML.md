# HTML

Markup language for browsers.

Based on XML, but doesn't follow its specification.

- [HTML](#html)
  - [Semantic HTML](#semantic-html)
  - [`meta` tag](#meta-tag)
    - [`http-equiv` property](#http-equiv-property)
  - [Web components and the shadow DOM](#web-components-and-the-shadow-dom)
  - [HTML entities](#html-entities)
  - [`select` vs `datalist`](#select-vs-datalist)
  - [`progress` vs `meter`](#progress-vs-meter)
  - [`button` vs `input type button`](#button-vs-input-type-button)
  - [Best practices](#best-practices)

## Semantic HTML

A semantic element clearly describes its meaning to both the browser and the developer.  

Non-semantic: `div`, `span`, ...  
Semantic: `form`, `article`, `footer`, `section`, ...  

Semantic structure:  
- header
- nav - a set of navigation links
- section
- article - independent, self-contained content
- aside - something aside from content, e.g. sidebar
- footer

Helpers:  
- details - can be closed or opened
- summary - defines heading for the details element

## `meta` tag

Metatags are located in the head and contain metadata.

In most cases, they contain key-value pairs.

This tag should be added to all web pages for correct handling of scaling:
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

Most common meta tags
- Description.
- Open graph content descriptions (og:...).
- Technical (robots, viewport, ssr, charset, ...).

### `http-equiv` property

This property allows to simulate HTTP headers, e.g. `refresh`, `content-type`, etc.

## Web components and the shadow DOM

Web component is an encapsulated instance of a JS class that has its own rendering mechanic.

The result of that render is the shadow DOM.

Templates are used to create new components. Slots may be used inside them to insert children from outside.

## HTML entities

Character entities are frequently used to display reserved characters in HTML:

`&nbsp;` is non-breaking space  
`&lt;` is "<"  
`&euro;` is "€"  

## `select` vs `datalist`

- Select only provides options
- Datalist provides options and allows custom input

## `progress` vs `meter`

- Progress is for specific task
- Meter is for gauges like disk space and memory usage

## `button` vs `input type button`

You can place children into button, but not inside input.

## Best practices

- Use concice `<!DOCTYPE html>`
- Use concice charset form: `<meta charset="utf-8">`; preferrably in the first 1024 bytes
- Use concise `<html lang="ru">` attribute
- Don't link favicon explicitly, browsers fetch it automatically
- Use `rel="noreferrer"` on links with `target="_blank"` to disable access to `window.opener`
