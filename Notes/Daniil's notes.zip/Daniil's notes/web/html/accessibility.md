# Accessibility

- Don't remove the :focus outline.
- Aria-hidden for icons.
- `.sr-only` class to replace icons with no alt (e.g. SVG).
- `aria-disabled` instead of `disabled`; show error message on disabled button press.
- Use accessibility linters.
- Respect `prefer-reduced-motion`.
- Add "Skip to content" button.
- Allow all interactive elements to be activated with keyboard.
- Use semantic html; if not possible, use aria roles.
