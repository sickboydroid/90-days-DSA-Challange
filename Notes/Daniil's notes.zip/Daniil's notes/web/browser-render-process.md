# Browser render process

## Step 1 - DOM.

Parse HTML to DOM (can be started even when only a part of document is transferred, e.g. first 14kb).

## Step 2 - CSSOM.

The browser goes through each CSS rule and creates a tree of parent, child, sibling relationships (CSSOM).

## Step 3 - render.

- Style: combines DOM and CSSOM. Traverses each visible node of the DOM tree and applies CSSOM rules to them.
- Layout: determines location and size of each element.
- Paint: each box calculated during the layout stage is converted to pixels.
- Composting: determines the right order of drawing the different layers of the document.
- Reflow: subsequent layouts.
