# Miscallaneous web stuff

- [Miscallaneous web stuff](#miscallaneous-web-stuff)
  - [What is a micro-frontend?](#what-is-a-micro-frontend)
  - [Frontend-backend communication options.](#frontend-backend-communication-options)
  - [Content Security Policy](#content-security-policy)
  - [TLS](#tls)
  - [Formatters vs Linters](#formatters-vs-linters)
  - [Progressive web apps](#progressive-web-apps)
  - [Virtual scrolling](#virtual-scrolling)
  - [Storybook](#storybook)

## What is a micro-frontend?

A component that is exported from application without the need to create a separate NPM module.

## Frontend-backend communication options.

1. Plain HTTP request
2. AJAX
3. WebSocket

## Content Security Policy

Content Security Policy (CSP) is needed to mitigate CSS and data injections.

Allows to specify valid sources for content (img-src, script-src, ...).

Makes `X-Frame-Options` header (used for restricting displaying the page inside an iframe) obsolete.

## TLS

TLS is a application-layer cryptographic protocol.

The resulting connection is:
- Authenticated: both parties are sure there is no man-in-the-middle.
- Private: data is encrypted.
- Reliable: data is checked for errors.

## Formatters vs Linters

- Formatters: rewrite code so that it follows the formatting guide.
- Linters: hint at bad practices (including formatting), which are sometimes auto-fixable.

## Progressive web apps

PWAs are a way for websites to provide user experience comparable with native apps:
- Installable apps.
- Offline support.
- Native APIs (contacts, share, push notifications, ...).
- etc.

## Virtual scrolling

With virtual scrolling, only elements in the viewport are rendered.

## Storybook

Storybook allows to isolate and organize all of the frontend components in the codebase.

Each component can be previewed with different parameters.

Also supports testing (unit/performance/visual regression).
