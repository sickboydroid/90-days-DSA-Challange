# Bundlers

Bundlers compile the source code (typically from a single entry) into one or more optimized bundles.

## Webpack

Uses loaders (babel-loader, sass-loader, css-loader, style-loader, ...) for different types of files.

Sometimes plugins are also needed.

Note: loaders are executed right-to-left in the config file.

## Vite

Optimizes dev speed by using two tricks:
- Dependencies are pre-compiled with esbuild since they change very rarely.
- Source files are served in esmodule form which allows for faster update when just one file is updated.

## Other bundlers

- Rollup, parcel, browserify: alternatives to webpack.
- Esbuild: 100x faster than regular bundlers, but missing some crucial features.
