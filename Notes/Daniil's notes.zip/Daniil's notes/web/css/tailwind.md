# Tailwind CSS

CSS framework packed with classes like `flex`, `pt-4`, `text-center` and `rotate-90` that can be composed to build any design directly in HTML.

Tailwind CSS works by scanning all of your HTML files, JavaScript components, and any other templates for class names, generating the corresponding styles and then writing them to a static CSS file.

## Pros and cons

In general, tailwind is good if you want to write CSS quickly, but it takes time to learn.

### Pros

1. Fast development
2. Simplifies workflow by automatically purging unneeded styles
3. Has a lot of built-in classes

### Cons

1. Learning overhead
2. Mixing styles and HTML

## Tips

- Cheatsheet: https://nerdcave.com/tailwind-cheat-sheet
- Generally, pseudo-elements are not needed; use regular elements instead
