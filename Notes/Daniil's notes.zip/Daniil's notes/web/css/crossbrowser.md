# Cross browser adaptation

- Write valid HTML and CSS
- Add fallback for browsers that don't support certain features
