# CSS common stuff

- [CSS common stuff](#css-common-stuff)
  - [CSS box model](#css-box-model)
  - [Selector specificity](#selector-specificity)
  - [What is a stacking context?](#what-is-a-stacking-context)
  - [What are CSS modules?](#what-are-css-modules)
  - [What is BEM?](#what-is-bem)
  - [Feature differences](#feature-differences)
    - [`display: none` vs `visibility: hidden`](#display-none-vs-visibility-hidden)
    - [`display` values: `block` vs `inline` vs `inline-block`](#display-values-block-vs-inline-vs-inline-block)
    - [`min()`, `max()`, `clamp()`](#min-max-clamp)
    - [`:root` vs `html`](#root-vs-html)
    - [`em` vs `rem`](#em-vs-rem)
    - [`100vh` vs `100%` on mobile](#100vh-vs-100-on-mobile)
  - [Properties reference](#properties-reference)
    - [`position`](#position)
    - [`inset`](#inset)
    - [`margin-inline`](#margin-inline)
    - [`margin-block`](#margin-block)
    - [`place-items`](#place-items)
    - [`::after` vs `:after`](#after-vs-after)
    - [CSS sprites (outdated tech)](#css-sprites-outdated-tech)
  - [Other notes](#other-notes)
  - [Useful links](#useful-links)

## CSS box model

Each HTML element is wrapped in a box that consists of four elements
(outer to inner):
- Margins
- Borders
- Padding
- Content
- Position (left/right/inset/...)

Additional properties:
- `display` - how to create the boxes (block - one box, inline - multiple boxes inside another box)
- `box-sizing` - whether to include padding/border into size
- `overflow` - what happens if content overflows the box size

## Selector specificity

Consists of three numbers: ID, count of classes, count of element types.

Compare these numbers left to right, if they're all equal - judge by order.

Inline styles overrule the aforementioned calculation.

`!important` declarations overrule everything.

## What is a stacking context?

Stacking context is a layer in the virtual 3D representation of the DOM.  

All elements in a stacking context move together along the Z axis.  

A new stacking context is created in many cases:
- `html`
- `position: absolute | relative | fixed | sticky`
- `isolation: isolate`
- `transform`, `filter`, `opacity` and other CSS properties

## What are CSS modules?

CSS modules is a CSS file where all style and animation declarations are scoped.

To import the module class from js use:

```js
import styles from "./style.css";

// className is a randomly generated string, which avoids any name collisions
element.innerHTML = '<div class="' + styles.className + '">';
```

## What is BEM?

BEM is a CSS methodology that separates all CSS rules into Blocks, Elements, and Modifiers, e.g.:
- `.confirm-button__text--disabled`

Created by Yandex.

## Feature differences

### `display: none` vs `visibility: hidden`

- `display: none` - tag is not visible, no space is allocated
- `visibility: hidden` - tag is not visible, but the space is allocated

### `display` values: `block` vs `inline` vs `inline-block`

- `block`: can set size/margins; create line breaks
- `inline`: can't set size/margins; don't create line breaks
- `inline-block`: can set size/margins; don't create line breaks

### `min()`, `max()`, `clamp()`

`min` and `max` - pick minimum and maximum of N values respectively.

`clamp` - receives three arguments, clamps the middle value between the outer ones (min and max).

Good for replacing media queries along with `min-width`, `min-height` (e.g. to set the limits for screen size).

Also extensively used in [grids](<./grid.md>).

### `:root` vs `html`

Since CSS is a general-purpose language, `:root` selector returns the root of the document, which is `html` in HTML, but may be different in other document types (SVG).

`:root` also has greater specificity (importance).

### `em` vs `rem`

`em` is relative to font size of parent.  
`rem` is relateive to font size of root element (usually 16px).

Use `em` when element's characteristics change depending on font size.  
In all other cases, use `rem`.  

### `100vh` vs `100%` on mobile

`100vh` is constant and is always equal to full screen height. It doesn't matter if address bar is visible or not.  
`100%` changes and is always equal to the visible screen height. Change happens when the address bar appears or disappears.  

## Properties reference

### `position`

Specifies elements position origin and how its children position inside it:
- `static`: normal flow; `top`/`left`/... don't affect position, `z-index` doesn't work.
- `relative`: normal flow + offsets + z-index; children may reference parent's size in percents.
- `absolute`: relative, but escapes normal flow.

### `inset`

Shorthand for `top`, `right`, `bottom`, `left` properties.

### `margin-inline`

Logical inline start and end margins (1-2 arguments).  
Usually this is left and right, but in other writing modes this is top and bottom.  

### `margin-block`

Logical block start and end margins (1-2 arguments).  
Usually this is top and bottom, but in other writing modes this is left and right.  

### `place-items`

Shorthand for `align-items` and `justify-items` in grid and flexbox layouts.

### `::after` vs `:after`

Single-semicolon one is an arhcaic form.  
Double semicolon is used for pseudo-elements now, and a single one is for pseudo-classes (e.g. `:hover`).  

### CSS sprites (outdated tech)

CSS sprites allow to put multiple images into one. Syntax:
```css
#element {
  width: 16px;
  height: 16px;
  background: url(img_navsprites.gif) 48 112;
}
```

## Other notes

- Prefer mobile-first design since usually desktop is more complex.
- Minimize the number of media queries. Replace them with modern CSS whenever possible.
- Use as little media queries breakpoints as possible. Usually one is enough.
- It's safe to assume that the user's screen is 320px or wider. Usually 360px+.

## Useful links

- [Cubic-bezier transition function generator](https://cubic-bezier.com)
