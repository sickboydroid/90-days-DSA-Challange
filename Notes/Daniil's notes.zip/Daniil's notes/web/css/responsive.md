# Responsive design

Adaptive design was a precursor to responsive design.

Adaptive: multiple possible screen dimensions.

Responsive: adjust design for any screen size. Only upper and lower sizes are limited.

## Principles

- Use `<meta name="viewport" value="width=device-width, initial-scale=1.0">` so that mobile devices don't pretend to be `960px` wide.
- Use `clamp(1rem, .8rem + .2vw, 1.2rem)` function in the specified form.
- Scale elements to fit the page (`max-width: 100%`).
- Use [flex](<./flexbox.md>)/[grid](<./grid.md>) with overflows.
- Use media queries, but don't create too many breakpoints.
- Use `ch` unit to specify element size in the number of characters.
- Use SVG icons.
