# Grid

- [Grid](#grid)
  - [Implicit grid](#implicit-grid)
    - [Firefox devtools](#firefox-devtools)
  - [Item sizes](#item-sizes)
  - [General positioning and alignment](#general-positioning-and-alignment)
  - [Individual elements positioning](#individual-elements-positioning)
  - [Areas](#areas)
  - [`minmax`, `auto-fit`, `auto-fill`, `fit-content`](#minmax-auto-fit-auto-fill-fit-content)
  - [Tips](#tips)

Consists of explicit grid and implicit grid:
- Explicit grid: defined by `grid-template-*`.
- Implicit grid: exists when there is overflow.

Rows/columns are called tracks.

Tracks are not indexed, places between them are.

## Implicit grid

When there is overflow, the browser looks at the `grid-auto-flow` property (`row` by default) and adds rows/columns implicitly.

The implicit tracks may be sized with `grid-auto-rows`/`grid-auto-columns`.

### Firefox devtools

- Black line: grid limits.
- Dashed line: explicit grid.
- Dotted line: implicit grid.

## Item sizes

In order of priority:
- Fixed size (either in template or size of the item)
- Fractional units
- Auto

Additionally, `max-content` is the `auto` that has higher priority than fractionals. E.g.:
```css
div {
  display: grid;
  /* This will make left and right columns equal and shrink them. */
  /* The middle one will take as much space as possible. */
  grid-template-columns: 1fr max-content 1fr;
}
```

## General positioning and alignment

`align-self` and `justify-self` on grid items allow them to specify which position inside their cell they want to take.

`align-items` and `justify-items` on grid itself sets the default values for `align-self` and `justify-self` for all grid items.

`align-content` and `justify-content` specify where the grid tracks should be if they aren't filling all of the available space.

## Individual elements positioning

`grid-column` is a shorthand for `grid-column-start`, `grid-column-end`.

`span <n>` may be used to specify starts and ends.

```css
.item {
  /* Indexes are based on gaps between columns, not columns themselves */
  grid-column: 1 / 3; /* Starts at column 1, ends at column 3 */
  grid-column: 3 / 1; /* Same */
  grid-column: 1 / -1; /* Starts at column 1, ends at the last column */
  grid-row: 1 / -1; /* This won't work unless grid-template-rows is specified */
  grid-column: span 2; /* Takes up 2 spaces */
  grid-column: span 2 / 5; /* Takes up 2 spaces, ends at column 5 */
}
```

## Areas

Areas may be defined using `grid-template-areas`.  
The value is a string or multiple space-separated strings.  
Each string contains area names.

Grid items may place themselves to a particular area with `grid-area <area name>`.  
`<area name>-start` and `<area name>-end` helpers are also available.  

## `minmax`, `auto-fit`, `auto-fill`, `fit-content`

In templates, `minmax` function allows to grow and shrink items dynamically.

`grid-template-columns: repeat(auto-fit, minmax(a, b))` fits as many items as possible.  
If there are not enough items, it tries to stretch the existing ones.  

`auto-fill` does the same, but squishes items instead.

`auto` uses up all available space. `fit-content(max)` may be used instead to clamp the maximum size.

## Tips

- `grid-template-columns` is usually enough since rows are created automatically.
- Images may push out of their grid cells if they have large enough natural size. Fix: `max-width: 100%` on the image.
- `grid-template: ...cols / ...rows` is a shorthand for columns and rows template.
