# Flexbox

## Main properties

- `justify-content`: place elements on the main axis.
- `align-items`: place elements on the secondary axis.
- `flex-direction`: switches main and secondary axis.
- `flex-wrap`: whether to wrap to the next row (squishes by default).
- `align-content`: where to place new rows after wrapping.
- `justify-items`: doesn't exist on flex, only on grid.

## `flex-basis`, `flex-grow`, `flex-shrink`, `flex`

- `flex-grow` stretches the item to fill the remaining space according to its value (proportion). Only active if value is not 0 and container has spare space.
- `flex-shrink` shrinks the item to make space according to its value (proportion). Only active if container is smaller then needed to fill all of the items.
- `flex-basis` is how much space the item should have.
- `flex` is a shorthand for `flex-grow`, `flex-shrink`, and `flex-basis`.

## Examples

Make an item take all available space:

```css
.container {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.child-number-n {
  flex: 1; /* flex-grow: 1; flex-shrink: 1; flex-basis: 0; */
  /* default: flex-grow: 0; flex-shrink: 1; flex-basis: auto; */
}
```
