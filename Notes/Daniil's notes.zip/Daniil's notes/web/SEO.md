## SEO

1. Optimize performance.
2. Build up backlinks.
3. Create new high-quality information.
4. Identify what people are searching for and use keywords on the website.
5. Use meta tags: title, description, keywords, etc.
6. Use semantic HTML (focus on h1).
7. Add sitemap and robots.txt
8. Use descriptive link texts in the anchor tags.
