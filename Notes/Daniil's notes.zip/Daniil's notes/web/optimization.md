# Website optimization.

- [Website optimization.](#website-optimization)
  - [Web performance metrics.](#web-performance-metrics)
  - [Optimization techniques.](#optimization-techniques)
    - [Write fast code.](#write-fast-code)
    - [Use minification, bundling, and code splitting.](#use-minification-bundling-and-code-splitting)
    - [Use GZIP compression.](#use-gzip-compression)
    - [Use resource hints.](#use-resource-hints)
      - [Preconnect.](#preconnect)
      - [Preload.](#preload)
      - [Prefetch.](#prefetch)
    - [Use CDN/Edge.](#use-cdnedge)
    - [Use caching.](#use-caching)
    - [Use SSR/SSG.](#use-ssrssg)
    - [Image optimization.](#image-optimization)
    - [14kb rule (HTTP/1.1, HTTP/2).](#14kb-rule-http11-http2)

## Web performance metrics.

- Time To First Byte (TTFB) - time between request and the first byte of response.
- First Contentful Paint (FCP) - time from when the page starts loading to when any part of the page's content is rendered on the screen.
- Largest Contentful Paint (LCP) - render time of the largest image or text block visible within the viewport, relative to when the page first started loading.
- First Input Delay (FID) - time from when a user is first able to interact with a page to the time when the browser is able to begin processing event handlers in response to that interaction.
- Time To Interactive (TTI) - point of time when the last long task finished and was followed by 5 seconds and main thread inactivity.
- Total Blocking Time (TBT) - time between First Contentful Paint (FCP) and Time to Interactive (TTI).
- Cumulative Layout Shift (CLS) - largest burst of layout shift scores for every unexpected (not caused by user's input) layout shift that occurs during page lifespan.
- Interaction to Next Paint (INP) - average time between user interaction and next frame presentation.

## Optimization techniques.

### Write fast code.

- HTML: use less tags.
- CSS: less specific selectors (less parts for simpler sibling/child relationships).
- JS: split long tasks using `setTimeout`/`requestAnimationFrame`.
- JS: pick dependencies that don't weigh much.

Note: you may also check connection speed using `navigator.connection` property.

### Use minification, bundling, and code splitting.

- Minification: removes or simplifies unnecessary code without changing the functionality.
- Bundling: merges multiple code files into bundles to decrease the [number of requests](<network/HTTP.md#maximum-number-of-parallel-http-requests>).
- Code splitting: divides app bundle into chunks that can be requested at different times.

### Use GZIP compression.

This is the most commonly supported compression algorithm of the web.

### Use resource hints.

Useful when font should be preloaded to prevent flash of unstyled text (FOUT).

#### Preconnect.

Used when domain is known but the exact path is not.

Usage: `<link rel="preconnect" href="https://domain.com/">` OR http header.

Should only be used for most critical resources; otherwise, use `rel="dns-prefetch"`.

If resource is not used within 10 seconds, connection is closed.

#### Preload.

Used for telling the browser to download the resource ASAP.

To preload scripts/fonts use attribute `as="script/font/..."`.

Useful to prevent FOUT (flash of unstyled text) in conjunction with `font-display: block` on the font-face.

Blocks rendering.

#### Prefetch.

Allows for something non-critical to happen earlier.

### Use CDN/Edge.

- CDNs store static content in multiple physical locations around the world to optimize response time.
- Edge also serves content from multiple locations, but edge servers may also run code.

### Use caching.

- HTTP caching with headers.
- Web workers for downloading critical resources.
- Push/pull CDNs.

### Use SSR/SSG.

- Client-side rendering: client receives empty HTML and a JS script to fill that HTML template on the client.
- Server-side rendering: HTML is generated upon client's request. Client receives full HTML and a JS script that "hydrates" the HTML once the page is ready.
- Static site generation: same as SSR, but HTML is generated at build time. ISR: regenerate static page (at time intervals/on demand).

### Image optimization.

Use modern image formats - webp/avif.

Optimize image sizes for different screens - with `srcset` or `<picture>`:
- srcset for performance.
- picture for performance and different images (e.g. cropped).

Load images lazily:
- Use native browser functionality: `loading="lazy"`.
- Use JS libraries (the most flexible and good-looking effect).

### 14kb rule (HTTP/1.1, HTTP/2).

If HTML is longer than 14KB, the browser will try to render based on data it has. This is where the most critical resources should be put.

For example, you may want to inline the most critical CSS to the start of HTML.

This happens due to TCP protocol implementation details (slow start mechanic). Doesn't apply for HTTP/3 since it uses QUIC/UDP.
