# JavaScript language

- [JavaScript language](#javascript-language)
  - [JavaScript data types](#javascript-data-types)
  - [Primitive methods](#primitive-methods)
  - [Type conversions](#type-conversions)
  - [Symbols](#symbols)
  - [Iterators](#iterators)
  - [Generators](#generators)
  - [Proxy and reflect](#proxy-and-reflect)
  - [Feature comparisons](#feature-comparisons)
    - [`isNaN` vs `isFinite`](#isnan-vs-isfinite)
    - [`parseInt(value)` vs `Number(value)`](#parseintvalue-vs-numbervalue)
    - [`==` vs `===` vs `Object.is`](#-vs--vs-objectis)
  - [Object operations](#object-operations)
    - [How to clone an object?](#how-to-clone-an-object)
    - [How to delete an object property?](#how-to-delete-an-object-property)
    - [Property flags and descriptors](#property-flags-and-descriptors)
  - [What is `this` in JavaScript?](#what-is-this-in-javascript)
  - [Prototype chain](#prototype-chain)
    - [`object instanceof Class`](#object-instanceof-class)
  - [Classes](#classes)
    - [`new Class()` vs new `Function()`](#new-class-vs-new-function)
    - [Class inheritance](#class-inheritance)
    - [Binding super](#binding-super)
  - [Promises](#promises)
    - [Promise API](#promise-api)
    - [`async`, `await`](#async-await)
    - [Custom promise implementation](#custom-promise-implementation)
  - [Event bubbling](#event-bubbling)
    - [`target` vs `currentTarget`](#target-vs-currenttarget)
  - [Script async vs defer](#script-async-vs-defer)
  - [`setTimeout` limitations in browser](#settimeout-limitations-in-browser)
  - [Currying](#currying)
  - [CORS and scripts](#cors-and-scripts)
  - [Workers](#workers)
    - [Web Workers](#web-workers)
    - [Service workers](#service-workers)
  - [DOM manipulations](#dom-manipulations)
    - [Intersection Observer](#intersection-observer)
  - [Fetch credentials](#fetch-credentials)
  - [WebRTC](#webrtc)
  - [ESNext features](#esnext-features)

## JavaScript data types

Basic types (7):
- number
- bigint
- string
- boolean
- symbol
- null (`typeof null` actually returns `object`, which is a known bug)
- undefined

And one complex type:
- object

## Primitive methods

Whenever a method is called on a primitive, a wrapper object is created and then destroyed: `15..toFixed()`

## Type conversions

Type conversions are implicit (type coersion). Strict mode doesn't affect that.

Basic types may be converted into string, number, or boolean depending on the context:
- For `+` operator, check if one of the operators is string; if so, convert both to string. Conversion result is obvious.
- For other math operations, convert to number. `null => 0, undefined => NaN`; strings are trimmed from both sides. If empty, then 0.
- In boolean context (control flow instructions), convert to boolean. Conversion is obvious (maybe except for `"0" => true`).

Objects are only converted into strings or numbers.

- For strings: check `obj[Symbol.toPrimitive]("string")`; if method absent, use `obj.toString()`, then `obj.valueOf()`.
- For numbers: check `obj[Symbol.toPrimitive]("number")`; if method absent, use `obj.valueOf()`, then `obj.toString()`.
- When unclear: check `obj[Symbol.toPrimitive]("default")`; if method absent, use `obj.valueOf()`, then `obj.toString()`.

## Symbols

By default, each symbol is unique: `Symbol("a") !== Symbol("a")`.

`Symbol.for` to get identity values: `Symbol.for("a") === Symbol.for("a")`.

System symbols:
- `Symbol.toPrimitive`
- `Symbol.iterator`
- `Symbol.asyncIterator`
- ...

## Iterators

Iterable objects are accepted in `for .. of` loops and spread expressions.

There are two possible values for `object[Symbol.iterator]`:
- Object with `next()` method.
- Generator.

Both should return objects of type `{ value: any, done: boolean }`.

`done` flag should only be `true` after all values have been passed with `done=false`.

## Generators

Generators are functions for which execution may be paused.

Generators return the same values as iterators.

`yield` operator returns values with flag `done` set to `false`.

Generators may also accept values. To do that, pass value into the next iteration:

```js
function* gen() {
  const answer = yield "question";
  
  return answer + 3;
}

const genInstance = gen();

const question = gen.next();
console.log(question); // { value: "question", done: "false" }
console.log(gen.next(2)); // { value: "question", done: "true" }
```

Return statement sets flag `done` to true, so the returned value won't appear in `for ... of` or in spreads.

Async generators are the same thing but they return promises and may be used in `for await ... of` loops, but not in spreads.

## Proxy and reflect

Proxy intercepts actions to the object (writing, reading, deleting property, ...) and may modify the outcome.

Reflect is a convenience wrapper for proxy.

## Feature comparisons

### `isNaN` vs `isFinite`

Both convert the passed value into a number.

- `isNaN` returns `true` only if the provided value is `NaN`;
- `isFinite` returns `false` only if the provided value is `NaN`, `Infinity`, or `-Infinity`

### `parseInt(value)` vs `Number(value)`

- `parseInt` reads the number until an invalid character and returns whatever has been read.
- `Number` reads the number and returns `NaN` if it meets any invalid characters.

### `==` vs `===` vs `Object.is`

- `==` performs type conversion and compares the results.
- `===` does not perform type conversion, it only compares the provided values.
- `Object.is` is similar to `===`, but returns true for `NaN`s and false for `+0` and `-0`.

## Object operations

### How to clone an object?

`Object.assign` copies own enumerable properties.

The most secure way would be to use `Object.defineProperties({}, Object.getOwnPropertyDescriptors(clonee))`.

### How to delete an object property?

The only way to do that is to use the `delete` keyword.

### Property flags and descriptors

Property flags (`Object.defineProperty`, `Object.getOwnPropertyDescriptor`):
- `writeable` - only write.
- `configurable` - delete, change property flags.
- `enumerable` - iterable in the `for ... in` loop and `Object.keys`.

`for ... in ...` loop iterates over both own and inherited properties, `Object.keys` - only over own properties.

`obj.hasOwnProperty` allows to check whether the property exists on the object itself.

## What is `this` in JavaScript?

`this` points to "the object before the dot" in most cases.  
When we call an object method, it uses a special internal reference type, that stores the object containing the method:

`object.method()` - `this` will be `object`

```
const method = object.method;
method() - `this` will be `undefined` in strict mode (reference is broken).
```

You can use a `bind` method to bind a particular `this` object to a function.

Arrow functions don't have their own `this` and take it from the outer lexical environment.

## Prototype chain

It's used to create new objects based on existing ones.

Uses internal `[[Prototype]]` reference.

If a property is not found, it will be looked for in parent.  
This only applies to reading; writing and deletion use the object itself.  

### `object instanceof Class`

Looks for whether `Class.prototype` is equal to `object.[[Prototype]]`, `object.[[Prototype]].[[Prototype]]`, and so on.

## Classes

### `new Class()` vs new `Function()`

Almost identical with three key differences:
- Different internal label.
- By default, class methods are non-enumerable.
- Classes are `use strict` by default.

### Class inheritance

```js
class First extends Second {
  ...
}

// First.prorotype.__proto__ === Second.prototype
```

`super` keyword may be used to access parents properties, but has to be used with caution:
- `super()` has to be called before accessing `this` if constructor is present.
- `super` isn't looked for in the lexical environment.

`super` works via a special internal `[[HomeObject]]` property.  
Otherwise, accessing `this.[[Prototype]]` would loop due to accessing the prototype of the object before the dot.  

### Binding super

```js
class Some {
  boundSuper = () => {
    super.someMethod();
  }
}

// Same as

function Some() {
  // `this` already exists
  this.boundSuper = () => {
    // This isn't allowed in functions, but this is basically what happens inside classes
    super.someMethod();
  }
}
```

## Promises

Promise allows to subscribe to its resolution.

Promises can be chained; if `then` returns promise, chain will continue from that returned value.

Return value from `finally` is ignored; instead, it passes whatever it received (result or rejection) to the next handler.

### Promise API

- `Promise.all`: returns if all succeeded.
- `Promise.allSettled`: returns in any case.
- `Promise.race`: returns first value, whether resolved or rejected.
- `Promise.any`: returns first resolved value, or rejects if all rejected.

### `async`, `await`

Statements in `async` functions execute synchronously until the first `await` is reached.

This is the same behavior as having the first statements in the `new Promise()` callback, and others in `then`s.

```js
async function a() {
  console.log(1);
  await null;
  console.log(3);
}
a();
console.log(2);

new Promise((resolve) => {
  console.log(1);
  resolve();
}).then(() => {
  console.log(3);
});
console.log(2);
```

### Custom promise implementation

```js
class MyPromise {
  #thens = [];

  #result;

  constructor(handler) {
    handler(this.#resolve.bind(this));
  }

  #resolve(result) {
    this.#result = result;

    this.#callThens();
  }

  #callThens() {
    this.#thens.forEach((then) => {
      queueMicrotask(() => then(this.#result));
    });

    this.#thens = [];
  }

  then(handler) {
    this.#thens.push(handler);

    this.#callThens();
  }
}
```

## Event bubbling

All events are created at the top of the DOM hierarchy - some on the root element, some on the window.  
Then the event starts moving down the chain of elements (capture phase).  
After it reaches the target object, it starts moving back up the chain (bubble phase).  
The event may be captured at either stage.  

### `target` vs `currentTarget`

- `currentTarget` is the element to which the event listener is attached to.
- `target` is the element that produces the event; it may be a descendant of `currentTarget`.

## Script async vs defer

Both allow to download the script asynchronously, without blocking the HTML parsing.

`defer` delays script execution until DOM content is ready.  
Scripts with `defer` parameter load in a specified order.  

`async` doesn't wait for DOM content readyness.  
Scripts with `async` parameter don't wait for each other to load.  

`async` doesn't affect inline scripts unless they are modules.

## `setTimeout` limitations in browser

- In inactive tabs, `setTimeout` will run at slower intervals
- There is a minimal delay of 4ms for consecutive `setTimeout` calls

## Currying

```javascript
function curry(func, ...oldArgs) {
  return (...newArgs) => {
    const args = [...oldArgs, ...newArgs];
    if (args.length >= func.length) {
      return func.apply(null, args);
    } else {
      return curry(func, ...args);
    }
  };
}

curry(multiply)(1)(2);
```

## CORS and scripts

- Regular scripts don't require CORS headers.
- Modules require CORS headers to be set on the endpoint.

## Workers

Shared under common `Worker` interface that supports `postMessage` method and `message` event for communication.

Workers run in a different context compared to the main script => no access to the page, only message-based communication.

### Web Workers

Kinds:
- Dedicated worker (`new Worker("script.js")`): only exists for a single script.
- Shared worker (`new SharedWorker("script.js")`): may share data with multiple scripts.

Allow to run separate scripts in parallel.

Communication is performed via messages.

Content security policy headers of the page don't apply to worker scripts.  
Insted, CSP headers should be provided separately on the worker script source.  

### Service workers

SW intercepts and modifies network requests (proxy pattern).

Mostly used for caching and providing offline support.

Only work via HTTPS.

Compared to web workers:
- Used for network manipulation instead of parallel work.
- One shared instance per origin/path instead of one instance per tab.
- Can't persist, only has a short lifecycle.

## DOM manipulations

Live collections:
- `document.getElementsBy*` return live collections, if DOM changes, the collections contents will too.
- `document.querySelectorAll` returns static collection.

Attributes and datas:
- `element.(set/get)Attribute` should be used for non-default properties.
- `element.dataset.something` may be used to access `<element data-something="">`.

Forcing repaint:
- Call `window.getComputedStyle(element)`.
- Access `element.offsetHeight`.

### Intersection Observer

This API allows to check for when an element intersects with viewport/other element.

It can also detect when a certain % of the element is displayed.

## Fetch credentials

`credentials` property may be used to send cookies and auth headers with requests.  
For cross-origin requests, credentials will only be passed if CORS header for credentials is set on the server.  

## WebRTC

This is an API for peer-to-peer communication between browsers.

Requires a remote signal server to establish connection, but after that the connection is P2P.

## ESNext features

[Link](https://www.javascripttutorial.net/es-next/) to ES6+ features.
