# React internal workings

- [React internal workings](#react-internal-workings)
  - [React codebase structure](#react-codebase-structure)
  - [React Fiber](#react-fiber)
    - [Main features](#main-features)
    - [Fibers](#fibers)
    - [Reconciliation](#reconciliation)
    - [Work](#work)
    - [Fiber trees](#fiber-trees)
    - [Fiber tree processing](#fiber-tree-processing)

## React codebase structure

[NPM modules](https://github.com/facebook/react/tree/main/packages):
- `react` is a core module that contains [high-level APIs](<./React-API.md>) and ways to create components (Component, PureComponent classes; JSX).
- `react-reconciler` contains fiber architecture diffing algorithm.
- `react-dom` is a renderer that binds React with the DOM.

## React Fiber

Fiber is a new React reconciler architecture that is meant to replace the Stack reconciler.

### Main features

Features:
- Rendering is split into chunks and can be paused.
- Rendering in response to certain events may be prioritized.

The main benefit of these additions is more responsiveness.

### Fibers

A fiber is a unit of work that can be prioritized, paused, or resumed.  
A fiber corresponds to some react element - e.g. component instance, DOM node, etc.  
Elements are re-created every time; fibers are reused as much as possible.  

Fiber relations (fields of the fiber object):
- Child: a pointer to the first child of the element.
- Sibling: a pointer to the next sibling of the element.
- Return: a pointer to the parent of the element.

### Reconciliation

In Fiber, reconciliation is split into two stages: Render and Commit.

Render phase:  
In the render phase, fibers are processed asynchronously.  
Functions: `beginWork`, `completeWork`.  

Commit phase:  
This is a synchronous stage (cannot be interrupted).  
Functions: `commitWork`.  

### Work

Render phase work:
- Changing state.

Commit phase work:
- Handling an event.
- Updating the DOM node.
- Firing an effect.

Some work is prioritized (`requestAnimationFrame`) or delayed (`requestIdleCallback`-like alternative).

### Fiber trees

There are two fiber trees consisting of fiber nodes:
- Current tree (what's on the screen) is stable.
- Work in progress tree (next render draft) is modified asynchronously (render phase).

When a render is complete (commit phase), pointers are switched (double buffering).

Each fiber in one of the trees has an `alternate` prop pointing to the same fiber in the opposite tree.

Some side effects (DOM updates, lifecycle methods) are queued and then executed synchronously on buffer swap (commit phase).

### Fiber tree processing

Processing algorithm (based on child-sibling-parent relationship):
1. React goes down the fiber tree by calling `beginWork` on the current component.
2. If it has children, it processes them recursively with the same algorithm.
3. Only after all children have been handled (`completeWork` has been called for them), `completeWork` is called on the current component.
4. Then, react processes the siblings, if there are any.
5. Otherwise, it returns, and parent `completeWork` will be executed for current element's parent.

The recursion is only logical here - it is actually a loop that can be stopped at any point (implicit call stack).
