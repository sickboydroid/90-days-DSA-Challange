# React classes stuff

- [React classes stuff](#react-classes-stuff)
  - [Class component lifecycle](#class-component-lifecycle)
    - [`componentDidMount`, `componentDidUpdate`](#componentdidmount-componentdidupdate)
    - [`getSnapshotBeforeUpdate`](#getsnapshotbeforeupdate)
    - [`componentWillMount`](#componentwillmount)
    - [`componentWillUnmount`](#componentwillunmount)
    - [`shouldComponentUpdate(nextProps, nextState)`](#shouldcomponentupdatenextprops-nextstate)
    - [`static getDerivedStateFromProps(props, state)`](#static-getderivedstatefrompropsprops-state)
    - [`static getDerivedStateFromError(error)`](#static-getderivedstatefromerrorerror)
  - [Pure components](#pure-components)

## Class component lifecycle

Mounting:
- `constructor` (state should be set as a property here, don't use `setState`)
- `getDerivedStateFromProps`
- `render`
- `componentDidMount`

Updating:
- `getDerivedStateFromProps`
- `shouldComponentUpdate`
- `render`
- `getSnapshotBeforeUpdate`
- `componentDidUpdate`

Unmounting:
- `componentWillUnmount`

### `componentDidMount`, `componentDidUpdate`

Called after render and DOM update, but before React displays these changes.

State can be modified here, which will discard the previosly rendered DOM and cause a re-render.

https://stackoverflow.com/a/68516279

### `getSnapshotBeforeUpdate`

Called after render but before DOM update.

Return value may be passed to [`componentDidUpdate`](#componentdidmount-componentdidupdate).

### `componentWillMount`

Called before the initial render. Allows to perform state update like `componentDidMount` without re-rendering.

Deprecated in favor of initializing state in constructors.

### `componentWillUnmount`

Called right before component unmounts and changes are written to the DOM.

### `shouldComponentUpdate(nextProps, nextState)`

May be used for optimization.

Deprecated in favor of [pure components](#pure-components).

### `static getDerivedStateFromProps(props, state)`

This method is always called before render and allows to perform one final change to the state.

Returns a state update object or `null` for no change.

### `static getDerivedStateFromError(error)`

Called when a descendant throws.

Allows to change state, probably before rendering anything? Not stated clearly in the docs.

## Pure components

Pure components are just class components for which [`shouldComponentUpdate`](#shouldcomponentupdatenextprops-nextstate) method is implemented with shallow prop and state comparison by default.
