# Node.js

V8-based JavaScript runtime for desktop.

- [Node.js](#nodejs)
  - [Structure](#structure)
  - [Node event loop](#node-event-loop)
  - [Streams](#streams)
  - [Single thread benefits](#single-thread-benefits)
    - [Single-threaded non-blocking I/O](#single-threaded-non-blocking-io)
  - [Worker threads](#worker-threads)

## Structure

Consists of four main parts:
- Core library written in JS
- V8 for transforming js into machine code (event loop is not used)
- libuv for orchestration (event loop, thread pool)
- Node bindings (C++ functions pretending to be JS functions, fs/network I/O)

## Node event loop

Different from V8 event loop. Has 8 different queues in total.

Callback queues:
1. Timers
2. I/O callbacks deferred from previous iteration
3. Idle (internal queue)
4. New I/O callbacks
5. `setImmediate` callbacks
6. Closing callbacks

In between each of them, two secondary event queues execute:
1. `nextTick` queue
2. Microtask queue

`setImmediate` callbacks execute right after I/O callbacks.  
If there aren't any, executes immediately (undetermined whether before or after `setTimeout`).  

`nextTick` task is executed before microtask unless it's queued during microtask queue execution and there are still items in the microtask queue:

```javascript
process.nextTick(() => console.log("nextTick")); // First
queueMicrotask(() => console.log("microtask")); // Second

queueMicrotask(() => {
  process.nextTick(() => console.log("nextTick")); // Second
  queueMicrotask(() => console.log("microtask")); // First
});
```

## Streams

Node JS is based on the stream abstraction for I/O operations.

Stream kinds:
- Readable
- Writeable
- Duplex (read & write)
- Transform

Communication is event-based:
- `write` and `end` methods.
- `data` and `end` events.

Can be piped one into another with `pipe` method.

## Single thread benefits

Most I/O operations are not CPU-intensive. They mostly consist of waiting for response from OS/network.

Threads are expensive to create, especially when there are lots of I/O requests.

Thus, single-threaded model with callbacks for I/O is more lightweight.

### Single-threaded non-blocking I/O

Node uses demultiplexer similar to nginx.

Calls to I/O operations are dispatched to OS and are thus non-blocking.

Once I/O operation is completed by OS, it produces an event/executes a callback for that operation.

## Worker threads

Allow to create separate threads for JS execution without having to use child processes.

Mainly help with CPU-intensive work; I/O operations are handled just well in a single thread.

Main thread script:

```js
const { Worker } = require('node:worker_threads');

function splitActionToThreads(datas) {
  return Promise.all(
    datas.map(
      (data) => new Promise(
        (resolve, reject) => {
          const worker = new Worker("worker-script.js", {
            workerData: data,
          });

          worker.on("message", resolve);
          worker.on("error", reject);
        }
      )
    )
  );
}
```

Worker script:

```js
const { workerData, parentPort } = require('node:worker_threads');

performSomeCalculation(workerData).then((result) => parentPort.postMessage(result));
```
