# React patterns.

## `useEffect` for internal syncing.

`useEffect` should only be used for syncing with external stores (localStorage, API, ...).

If `useEffect` only updates internal state depending on other internal state:
1. Replace derived state with simple calculation, possibly with `useMemo`.
2. Move the derived update into the `useEffect` that generates initial state change.

## Refs for internal operations.

Refs only exist to support interactions with external items during side effects.

They shouldn't be modified or read during render (pure function principle).

## Force child to re-mount.

Whenever we need to re-mount a child when something changes in parent, change the `key` prop of the child.

E.g. set it to value dependent on the thing that changed.

Changing the `key` prop re-mounts the component.  
Changing any other prop re-renders the component.  

## Optimize component re-renders

A component re-renders in three cases:
- Props change
- State changes
- Parent re-renders with changes

Thus, render props can be used to pass A to B so that whenever B re-renders, A doesn't re-render.

Another option is `React.memo`, but it leads to double prop recalculation if props change.

## Persistent value.

The best option is `useState` without setter.

```ts
const [constantValue] = useState(() => new Value());
```

## Uninitialized `useState` type.

There is a shorthand for `useState` when we initialize the value after initial render:

```ts
// This is the same as useState<ValueType | undefined>(undefined)
const [value, setValue] = useState<ValueType>();
```

## Avoid using contexts

Contexts force re-renders on all components that use them.

Prefer state managers.

## Prevent information leaks.

Don't allow a generic component to have a piece of information about another component.

## Don't allow low cohesion.

A component may have "god" qualities and control too much, or some functionality may be stretched inside multiple components.

Usually in this case we have to jump a lot inside one or multiple files whenever we need to make a change.

## React folder structure opinions.

Den Abramov: move stuff around until it feels right.

Theo Browne: keep everything in one file until it starts to be annoying. Then and only then you should create hierarchies.
