# React JS

React is a declarative unopinionated UI framework.

- [React JS](#react-js)
  - [Pros and Cons of React](#pros-and-cons-of-react)
  - [Component, element, component instance](#component-element-component-instance)
  - [React component lifecycle](#react-component-lifecycle)
  - [What are hooks?](#what-are-hooks)
  - [What are higher-order components?](#what-are-higher-order-components)
  - [What is virtual DOM?](#what-is-virtual-dom)
    - [Virtual DOM vs Incremental DOM](#virtual-dom-vs-incremental-dom)
  - [Reconciliation](#reconciliation)
  - [Why are keys needed](#why-are-keys-needed)
  - [What are the valid JSX element types?](#what-are-the-valid-jsx-element-types)
  - [Refs](#refs)
  - [What are server components?](#what-are-server-components)
    - [Client components](#client-components)
    - [Server components](#server-components)
    - [Hybrid components](#hybrid-components)
  - [React event system](#react-event-system)
  - [State update batching](#state-update-batching)
  - [React strict mode](#react-strict-mode)

## Pros and Cons of React

Pros:
1. Easy to learn (overall / compared to angular).
2. VDOM is fast. Custom renderers are be faster, but require a lot more effort to write.
3. Uniform => easier to manage complexity as app grows.
4. Component reuse - it's easy to plug-in any react component.
5. Very simple - only handles rendering, isn't opinionated on anything else.
6. Declarative code.

Cons:
1. JSX is not a default JS feature => transpiler needed.
2. Poor documentation.
3. VDOM is not optimal.

## Component, element, component instance

Component: class or function that create an element.

Element: plain JS object that describes how a component should be rendered.  
Created by using the component in JSX.  
Different from just calling the function: doesn't return the return value of the component, but the component itself.  

Component instance: concrete instantiation of class component that stores its state in `this`.  
Created on mount, destroyed on unmount.  

## React component lifecycle

1. Mounting: initial render; component is added to the DOM.
2. Update: component re-renders as a response to state/props change or parent re-render.
3. Unmounting: component is cleaned up and removed from DOM.

## What are hooks?

Hooks are a way to "hook" into the component lifecycle.

Hooks allow functional components to be stateful.

Limitation: error boundaries (components that handle errors further down the tree) are not supported.

## What are higher-order components?

Higher-order components (HOC) are functions that take one component and return a new one.

## What is virtual DOM?

VDOM is a concept where a representation of UI is kept in JS memory and synced with the real DOM.

### Virtual DOM vs Incremental DOM

Virtual DOM keeps virtual representation of each component in memory. Changes are applied to VDOM and then synched with the real DOM.  
Fast, but not memory-efficient.  

Incremental DOM uses real DOM to locate changes. Each component is compiled into a set of instructions that create the DOM tree.  
Slow, but memory-efficient.  

## Reconciliation

Reconciliation is a process of keeping the real and virtual DOMs in sync.

Runs in O(N) time by comparing element types and their keys.

Process:
1. Render virtual DOM when there is a change.
2. Calculate the difference between previous VDOM and newly generated VDOM.
3. Patch the differences.

## Why are keys needed

Reconciliation runs by comparing elements one by one. Without keys, addition of a new element to the beginning of the list would lead to re-mounting of each element.

Keys allow the reconciliation algorithm optimize addition and removal of elements.

## What are the valid JSX element types?

- DOM element
- Class component
- Function component
- `null`

## Refs

Refs are a way to reference the underlying DOM nodes of React components.

Refs only exist on DOM elements and class components.

Ref updates happen before [`componentDidMount` and `componentDidUpdate`](<./React-old.md#componentdidmount-componentdidupdate>).

Ref of a child component may be exposed as ref of parent using [`React.forwardRef`](<./React-API.md#reactforwardref>).

## What are server components?

There are three types of React components:

### Client components

Client-only, full script is passed to the client.

This is the default, allows stateful components.

### Server components

Server-only, client receives minimal js.

Can't have state; props can't be functions.

Can easily access backend libraries without sending them to the client => bundle size improvement, code simplification.

### Hybrid components

Both client and server.

Can't have client state/server code.

Only jsx.

## React event system

React implements its own event system to avoid browser compatibility issues.

Before react 16, events were pooled => to use an event later, you had to call `e.persist()`.

## State update batching

Pre React 18:

React will batch state updates performed in a single event callback.

This does not apply to callbacks from different events - in this case, update will happen before the next callback is applied.

React 18:

React will batch any state changes, even outside of callbacks.

## React strict mode

Strict mode mounts components twice to hint at invalid effects/refs/other escape hatches.

All effects should have cleanups.

Also warns about deprecated APIs usage.
