# Notes for solving algorithms/data structures tasks in JavaScript

Arrays:
- Clearing an array: `arr.length = 0` - fully removes all elements.
- Creating an arary of length: `Array.from({ length })` - initially filled with `undefined`.
- Sorting is not guaranteed to be stable.
- Strings are iterable.

General notes:
- Data structures often return iterables/array-likes instead of arrays. Always convert using `[...notArray]`.
