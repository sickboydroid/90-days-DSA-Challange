# React DOM

React DOM is a library that contains reconciller (common with react-native-renderer) and bindings to the DOM.

- [React DOM](#react-dom)
  - [Portals](#portals)
  - [`React.flushSync`](#reactflushsync)
  - [`findDOMNode(component)`](#finddomnodecomponent)
  - [`createRoot`](#createroot)
  - [`hydrateRoot`](#hydrateroot)

## Portals

Portals are a way to render an element at the same DOM level as root.  
This is helpful for modals, tooltips etc.  

## `React.flushSync`

This function forces React to flush any updates passed to it synchronously.  
The function itself is synchronous, so any code that comes after it already uses updated DOM.  
Significantly hurts performance.  

Doesn't cause a re-paint, only an update of DOM elements.  

## `findDOMNode(component)`

Finds DOM node created by this component.

Refs are preferred over this.

Throws on unmounted components.

## `createRoot`

Creates a root with a `render` method that can be used to tell react to start updating the specified component:

```jsx
import ReactDOM from "react-dom";
import App from "./App";

const rootNode = document.querySelector("#root");

const root = ReactDOM.createRoot(rootNode);

root.render(<App />);
```

## `hydrateRoot`

Similar to `createRoot`, but is able to reuse the existing HTML nodes.

Render method doesn't need to be called.

```jsx
import ReactDOM from "react-dom";
import App from "./App";

const rootNode = document.querySelector("#root");

ReactDOM.hydrateRoot(rootNode, <App />);
```

Client rendering and server rendering should produce exactly the same output.
