# Internal workings of JavaScript

- [Internal workings of JavaScript](#internal-workings-of-javascript)
  - [Garbage collection in js](#garbage-collection-in-js)
    - [Memory leaks](#memory-leaks)
  - [Lexical environments](#lexical-environments)
  - [Non-existing, uninitialized, and unassigned variables](#non-existing-uninitialized-and-unassigned-variables)
  - [Closures](#closures)
  - [Event loop](#event-loop)
  - [`requestIdleCallback`](#requestidlecallback)

## Garbage collection in js

All reachable objects are cleaned up.

This includes objects that can only be referenced via a function's local `[[Environment]]`.

### Memory leaks

- `var`, `window.prop`
- Timers and intervals
- Closures

## Lexical environments

Lexical environments define which values can be accessed from inside some scope.

Every block of code has a hidden `[[Environment]]` property that stores all local environments and functions.

Every `[[Environment]]` stores a reference to it's outer `[[Environment]]`. If a variable is not found in the local environment, it's looked for in the outer one, and so on, going up the chain.

- As soon as execution reaches a block of code, variables are defined.
- As the code execution reaches variables itselves, they may be initialized.
- Function declarations are defined and initialized as soon as execution reaches the containing block of code.

```js
function func() {
  console.log(variable);
}

const variable = 3; // Global lexical environment now has `variable`

func(); // 3
```

## Non-existing, uninitialized, and unassigned variables

- Non-existing variables are absent in the lexical environment chain.
- Uninitialized variables exist (execution reached the containing block of code), but haven't yet been initialized.
- Unassigned variables have been initialized (execution reached the declaration statement), but haven't yet been assigned value.

First two cause `ReferenceError` when trying to access.

## Closures

Closure is a function that keeps track of outer variables and can access them.

In js, all functions are closures. They remember a hidden `[[Environment]]` property that stores outer variables.

## Event loop

```js
while (pollEventSynchronously()) {
  handleEvent();
}
```

JS is single-threaded, but other threads can perform tasks and add their callbacks to the main queue.  
For example, when we call `setTimeout(callback, ms)`, we don't block the main thread for `ms`.  
Insted, we keep executing whatever is running on the main thread, but after `ms` `callback` gets added to the queue.  
Same for I/O operations - only their callbacks are handled synchronously.  

60 times per second, there is a special detour in the event loop for calculating the CSS and painting the page.  
If a task takes too long, it will block the entire event loop, including the page rendering.  
JS guarantees that a task will end before the page is rendered.  

You may run a piece of code right before the page render via `requestAnimationFrame`.

Microtasks are run whenever a JS completes executing a regular task or `rAF`.

Task, microtask, and `rAF` queues all work differently from each other:
- Task queue runs a single element, then allows the loop to continue.
- Microtasks queue runs until there are no elements left. This could be blocking.
- `rAF` queue runs until there are no old elements. All new elements wait until another loop.

## `requestIdleCallback`

`window.requestIdleCallback` provides a way to schedule execution of something whenever the browsers idles (isn't rendering).

Callback recieves the function with which it can check the deadline (time remaining to work).  
This deadline is only a hint and can technically be ignored.  

Difference from `setTimeout`:
- `setTimeout` executes no earlier than the specified timeout.
- `requestIdleCallback` executes no later than the specified timeout, but yields to renders if the timeout is not yet reached.

Idle callbacks scheduled inside other idle callbacks are guaranteed to be executed after the next paint.

React uses its own implementation since `requestIdleCallback` is too restrictive (doesn't render as often as it should).
