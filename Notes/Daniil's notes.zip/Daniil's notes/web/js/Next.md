# Next JS

Next is an opinionated web development framework based on React.  
Next provides out-of-the-box building blocks for applications.  

## In-the-box Next components

### `Link`

`Link` element provides client-side navigation that is faster than the native one.

In production, `Link` elements pre-cache the destination pages one level deep.  
In dev mode, elements are not pre-cached.  

`Link` should only be used for internal navigation. For external links, simply use `<a>`.

### `Head`

`Head` component allows to specify items inside the documents `<head>` component.

#### Difference between `next/Head` and `document/Head`.

`document/Head` is only rendered on the server (statically/dynamically).

`next/Head` exists on the client and should be used for the rest of the cases (per-page / `_app.tsx`).

### `Script`

`Script` component allows to specify when the script should be loaded and a callback that runs as soon as the script loads.

### `Image`

`Image` component adds modern image features that improve application performance and metrics.

`Image` is automatically scaled and optimized for different devices.

## Styling

It's a good practice to use CSS modules for Next components.

Global styles may only be imported in `_app.js`.

SASS syntax is supported from the box, but `sass` package needs to be installed for it to work.

## Static site generation

By default, all pages are generated statically.

To add custom logic that has to run before the page is generated, use `getStaticProps`.  
In production, it runs once at build time.  
In development, it runs on every request.  

## Server-side rendering

To make the page server-generated, use `getServerSideProps`.  
This function receives a `context` argument that looks similar to a request info object from express.  

The logic inside this function will be run on each request.  

## Dynamic routes

To create dynamic routes for file `/pages/posts/[id].js`, use `getStaticPaths`.

It should return the following JS object:
```js
const result = {
  paths: [
    {
      params: {
        // These ids will be used in path, e.g. https://website.com/posts/first-page-id
        id: 'first-page-id',
      },
    },
    {
      params: {
        id: 'second-page-id',
      },
    },
  ],
  // This indicates that if the user specifies invalid dynamic path, we should return 404
  fallback: false,
};
```

Paths like `/pages/posts/a/b/c` can be caught with files like `[...id].js`.
In this case, `id` values return from `getStaticPaths` should be arrays like `['a', 'b', 'c']`.

## Middleware

Allows to run code as the request comes in.

Modifies the response by changing content, setting cookies, etc.

## Static file serving

Anything placed in the `public` directory will be served statically.

## Caching policy

To change the cache policy, set `Cache-Control` headers in `next.config.js`.
