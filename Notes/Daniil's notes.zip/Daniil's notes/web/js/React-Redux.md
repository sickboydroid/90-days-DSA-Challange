# Redux

Redux provides a way to create a global state storage with one-way flow of data in a react app:
1. The user interacts with the app.
2. An action event is created and dispatched.
3. A reducer handles the event and produces a new state.
4. The old state is replaced.
5. The UI that depends on changed parts of state updates.

The state is immutable and fully replaced on an event.

## Redux vs Context vs Prop Drilling

Redux has more boilerplate, but after that it is easier to manage dynamic state.

Context is used for static values since each change forces every consumer to re-render.

Prop Drilling is fine in most cases and may even become more of a problem with render props.

## Redux vs Flux vs MVC

[MVC](<../../../../general/MVC.md>): abstract pattern that may have unidirectional or bidirectional data flow.  
Both redux and flux are standartized unidirectional MVC.  

Redux: unidirectional data flow, single store.

Flux: unidirectional data flow, multiple stores.
