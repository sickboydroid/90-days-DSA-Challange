# PRPL

- Preload the critical resources.
- Render the initial page ASAP.
- Precache remaining resources.
- Lazy-load other routes and non-critical assets.
