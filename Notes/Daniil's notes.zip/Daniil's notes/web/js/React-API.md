# React API reference

- [React API reference](#react-api-reference)
  - [React top-level APIs](#react-top-level-apis)
    - [React.forwardRef](#reactforwardref)
    - [React.memo](#reactmemo)
    - [React.Children](#reactchildren)
    - [React.lazy, React.Suspense](#reactlazy-reactsuspense)
  - [React hooks](#react-hooks)
    - [useState](#usestate)
    - [useEffect](#useeffect)
    - [useContext](#usecontext)
    - [useReducer](#usereducer)
    - [useMemo](#usememo)
    - [useCallback](#usecallback)
    - [useRef](#useref)
    - [useId](#useid)
    - [useImperativeHandle](#useimperativehandle)
    - [useDebugValue](#usedebugvalue)
    - [useTransition](#usetransition)
    - [useDeferredValue](#usedeferredvalue)

## React top-level APIs

### React.forwardRef

Allows to pass ref from parent to child.

### React.memo

Allows to skip component re-render unless its props have changed.  
Without it, if parent re-renders, the child re-renders too even if the props are the same.  
By default, the comparison is shallow. A comparison function may be passed to change that.  
This is only a performance helper, not a guarantee.  

Compared to `PureComponent`, memo doesn't compare state, only props.

### React.Children

Convenience wrapper for `props.children` that allows to avoid endless typechecking.

Children may be a string, a number, a single component, multiple components, null etc.

This API allows to operate on children more easily by mapping, foreaching, converting to an array etc.

Example usage: `React.Children.map(props.children, mappingFn)`.

### React.lazy, React.Suspense

Allow to fetch a component dynamically, e.g. if the component is not needed on the initial render:  

```jsx
const DynamicComponent = React.lazy(() => import("./path/to/DynamicComponent.jsx"));

const ParentComponent = () => {
  return (
    <React.Suspense fallback={Spinner}>
      <DynamicComponent />
    </React.Suspense>
  );
};
```

Dynamic components may be deep inside the Suspense tree.  
The best practice is to put `React.Suspense` where you want the loader to be.  

## React hooks

Hooks provide ways to "hook into" component lifecycle.

Benefits:
1. They allow functional components to have state.
2. They greatly simplify working with lifecycle.

### useState

Returns value and a function to update it.  
Initial value is passed as an argument.  
Updating a value causes a re-render of the component.  

Update function won't change on re-renders, so it's safe to omit from dependency arrays.  

Use functional updates for when the new state depends on the old one.  
https://stackoverflow.com/a/73115899

Pass a function to the initial state to only evaluate the value on initial render.  

If state is updated to the same value as previous, react will not render children or fire effects.  
It may have to re-render the specific component.  

React may group multiple state updates into a single render. Use `flushSync()` to force update.  

### useEffect

Accepts a function with imperative code with potential side effects.  
Anything besides rendering should happen inside `useEffect`s.  
It's an escape from React's functional paradigm towards imperative.  

Run on every completed render, after painting, before new render.  
Use `useLayoutEffect` for when an effect needs to be fired before painting.  
In React 18, renders that were initiated by user input will cause `useEffects` to run synchronously, before painting.  

Clean-up function runs before component is removed from the UI, and before each re-render.  

It's better to move functions that are used in useEffect to either outside of component, or to useEffect itself.  

### useContext

Accepts a context object created by calling `React.createContext`.  
Returns current context value (value of the nearest context provider).  

A component with `useContext` will always re-render on context value change, even if parents are memoed.  

### useReducer

```js
const [state, dispatch] = useReducer(reducer, initialArg, init);
```

`dispatch` function is always the same.  

If `init` is not specified, `initialArg` will be the initial state.  
Otherwise, it will be passed as an argument to the `init` function.  

If state is the same as previous, React will act the same way as in `useState` - won't re-render children or fire effects.

### useMemo

```js
const memoizedValue = useMemo(() => computeExpensiveValue(a, b), [a, b]);
```

Computes and returns new value only when one of the dependencies changes.  
Useful to avoid expensive calculations on every render.  

### useCallback

```js
const memoizedCallback = useCallback(
  () => {
    doSomething(a, b);
  },
  [a, b],
);#
```

Returns callback that only changes when one of the dependencies changes.  
Useful to avoid unnecessary renders when passing callbacks to children.  

Accepts any functions, including async ones.  

`useCallback(fn, deps)` is the same as `useMemo(() => fn, deps)`.  

### useRef

```js
const refContainer = useRef(initialValue);
```

Returns a container that stores a mutable value inside `.current` property.  
This container is kept the same during the entire lifetime of the component.  

Doesn't notify component about changes.  

### useId

Generates IDs that are stable across client and server to avoid hydration mismatch.

### useImperativeHandle

```jsx
useImperativeHandle(ref, createHandle, [deps])

function FancyInput(props, ref) {
  const inputRef = useRef();
  useImperativeHandle(ref, () => ({
    focus: () => {
      inputRef.current.focus();
    }
  }));
  return <input ref={inputRef} ... />;
}
FancyInput = forwardRef(FancyInput);
```

Creates a value that can be exposed to parent component when using `forwardRef`.  
Allows to replace native functions with custom ones.  

### useDebugValue

Display a label in React DevTools.  
Second argument is the function for when calculation is expensive; calculated when inspected in DevTools.  

### useTransition

```js
const [isPending, startTransition] = useTransition();
```

Allows to queue state transitions that have lower priority than other ones (all other state updates or UI callbacks).  
This helps with performance since these state updates yeild to more important (user interactions).

### useDeferredValue

```js
const deferredValue = useDeferredValue(value);
```

Returns copy of the accepted value that is changed with low priority.  
If component receives more urgent updates, `deferredValue` will be the same as in previous render.  
Once the urgent render is complete, `deferredValue` will be the new value.  
