Slow down, stay organized and focused

Ask questions: interview problems may be intentionally vague

Check termination cases

Practice a lot

Research the company you're interviewing at

Have fun, be energetic
