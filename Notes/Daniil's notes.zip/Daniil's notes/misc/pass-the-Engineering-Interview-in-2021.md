# Interview types

There are 3 types of interviews:
1. coding interviews - solve a problem
2. design interviews - solve an open design problem conceptually and practically
3. behavioral interviews - background, work experience, situation handling

Depending on what role you're interviewing for the amount of each type will change

There's a lot of publicly available information for the big companies, just look it up

# Coding interviews

## Preparation tips:
- always be coding, spend a lot of time on it
- be comfortable with at least one dynamic PL
- learn the complexities cheat sheet
- reinvent the wheel - rewrite common data structures
- solve a lot of competitive programming problems

Make sure you're clear on the problem you're asked to solve since sometimes interviewers won't give you all of the information required for the optimal solution and expect you to clarify

Be prepared for the follow-up questions as well

# Design interviews

The goal is to produce a system design that could realistically be implemented

## Tips:
- spend 5-10 minutes to understand all of the requirements and constraints
- go top-to-bottom, from box and arrow diagrams to low-level questions
ask questions. The interviewer may not immidiately course-correct you

## Prep tips:
- understand service-oriented architecture
- read about how companies build their large-scale systems
- watch youtube videos on solving design problems (e.g. for faang)
- put pencil to paper, practice

# Behavioral interviews

These interviews are used to check the recruit's culture, experience and background.

When answering behavioral questions, start on the conceptual level. Show your systematic approach to this type of problem.

## Prep tips:
- write the script (q&a with examples) - this article provides a good list of questions
- write down your principles of dealing with common workplace situations
- be active and help the interviewer get the information they need

Tip: provide feedback on the process. This will make the interviewer more open.

Source: https://davidbyttow.medium.com/how-to-pass-the-engineering-interview-in-2021-45f1b389a1
