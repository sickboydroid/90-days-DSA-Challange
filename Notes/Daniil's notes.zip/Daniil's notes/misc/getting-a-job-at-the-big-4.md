# Reasons for joining the big 4

Good reason to join such company is brand.
If you've worked on one of them you have a stamp saying "I'm at least this good".

The pay is good, at least 5k/month (this is internship).

They don't hire you based on your technology stack since they are so large.
Languages can be taught quickly, CS fundamentals/communication skills cannot.

# Which one to choose

The process is similar in all companies.

Don't obsess with one company.
If you've worked on one of them it will be easier to get a job at the others.
Even if you don't like the companies, it will be easier to join others.

# How to get a job at the big 4

## Get an interview

Your resume should be short (only one page).
Recruiters don't spend much time on reading resumes.
Show your achievements.

Do what you want, put it up on GitHub.
Participate in hackatons. They'll put pressure on you to develop.

Quantity beats quality. Learn from your mistakes faster.

Ask for referrals.

## Do well on the interview

The interviews are ~45min. The amount varies depending on a company.

The interviews are different from the other companies.
80%-100% of time is spent on coding questions.

You will be asked little behavioral questions.
Your behavioral skils will probably be determined implicitly during the interview process.
90% of the focus is on coding, so as long as you don't raise noticable red flags you'll be ok.

Go to glassdor or careercup. Someone may have leaked interview questions.

### The coding interview bible

Read "Cracking the coding interview"

It contains a bunch of interview questions

Skip any brain teasers questions

Don't skip OOP sections.
Even though the focus will be on the coding, you will be asked some design questions.

### Important preparation method - mock interviews

**This is the game changer for most candidates.**

1. Find a partner around your level of experience
2. Find a coding problem for your partner; make sure you understand it thoroughly
3. Schedule an interview with your partner; switch roles once you're done
4. As an interviewee, solve the problem:
  a. Clarify all details
  b. Discuss high-level approach
  c. Discuss your solution as you're writing it
5. As an interviewer:
  a. pick your partner's head for all they know
  b. guide them if they're lost

Do this 3-4 times a week.

## Internships

All of these companies except Google will give you the offer at the end of the internship.
