Facebook frontend process:
1. Phone screening: asking about your passion and what you'd like to change
2. Technical screening: technical questions/tasks
3. Onsite interview: problemsolving; whiteboarding is required to see how well the engineer can build from scratch
4. Interviewer debrief: all of the engineers discuss the recruit
5. Candidate review: all of the objective feedback is shared with engineering team; the decision is made

Recruiter is present during each process, so bond with your recruiter
