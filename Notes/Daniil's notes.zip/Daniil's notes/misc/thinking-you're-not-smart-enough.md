Preparation and luck matter.

You can get rejected multiple times, but getting the job just once makes up for all of it.

Don't be discouraged.

Don't try to be a genius. Collaborate often: even if you get critisied, there is nothing bad in it.

Skill only improves your luck.
Another good way to improve your luck is to keep applying.
