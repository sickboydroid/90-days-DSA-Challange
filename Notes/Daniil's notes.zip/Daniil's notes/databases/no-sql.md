# NoSQL

## NoSQL kinds

### Key-value store

Similar to a hash table: very fast reads and writes - O(1).
Used in simple models for rapidly-changing data.

### Document stores

Is centered around data documents (JSON, XML, binary, ...).
Document stores provide APIs to query based on the internal structure of the document.

### Wide column store

Similar to an SQL table, but has grouped column families.

### Graph database

Records = nodes, relations = edges.
These are good at representing complex relationships with lots of FKs or many-to-many relationships.
E.g. good for social networks.

## SQL vs NoSQL

| Parameter | SQL | NoSQL |
| --- | --- | --- |
| Structure | Strict | Dynamic, semi-structured |
| Relational | Yes | No |
| Complex joins | Yes | No |
| Clear scaling patterns | Yes | No |
| Speed | Fast index lookups | High throughput |
