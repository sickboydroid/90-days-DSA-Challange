# Consistency patterns

## Weak consistency

After a write, read may not ever see it.

Good for real-time systems (video chat, games) where the best effort approach is ok.

## Eventual consistency

After a write, reads will eventually see it.

Good for high availability.

## Strong consistency

After a write, reads will see it immediately.

Good for consistency.
