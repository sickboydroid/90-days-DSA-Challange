# Caching

In the cached DB model, dispatcher will first look for request results in cache.
If not found, the request will be propagated to actual DBs.
