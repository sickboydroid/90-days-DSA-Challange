# Database replication

Replication is a way of scaling the database.

## Master-slave replication

Master server at the top that handles both reads and writes.
Slave servers only handle reads.

Writes to master propagate to slaves.
If master goes offline, system continues to work in read-only mode.

## Master-master replication

Both masters serve reads and writes.
Writes are replicated.

These systems are either loosely-consistent or very slow.

## Benefits

1. Fits well in systems where reads are more frequent than writes (that is, most systems)

## Drawbacks

1. Data loss if master fails before writes are propagated
2. Replication is slow
