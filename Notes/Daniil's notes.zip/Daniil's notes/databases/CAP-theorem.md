# CAP theorem

A distributed data store has multiple instances with replicated data to keep the system from failing due to network flakyness.

In such system, we can only support two of these three guarantees:

1. Consistency - Every read receives the most recent write or an error
2. Availability - Every request receives a response, without guarantee that it is the most recent write
3. Partition Tolerance - The system continues to operate despite arbitrary partitioning due to network failures

Network is unstable, so partitioning generally has to be tolerated.
Thus, the choise is between C and A:
- CP - fail the operation when the network fails; this decreases availability
- AP - proceed with the operation; the read data may not be the latest, which produces inconsistency

AP may be good for [eventual consistency](<./consistency patterns.md#eventual consistency>).
