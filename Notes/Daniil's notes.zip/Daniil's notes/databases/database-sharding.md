# Sharding

To shard a table means to separate it into smaller chunks.

In vertical shards, table is separated by rows.  
Each partition has the same columns, but different rows.  
Usually these rows should not be related to each other.  

In horizontal shards, table is separated by columns.  
Each partition has the same rows, but different columns.  
Separation may be done by some data hash, or by data ranges.  

## Benefits

1. Horizontal scaling.
2. Speed up query times - for horizontal shards, there will be less rows per request.
3. Separate single point of failure into multiple.

## Drawbacks

1. Complexity, risk of data loss.
2. Shards may become unbalanced - for horizontal shards, some shards may be more used than the other ones.
This is called database hotspots. 
3. Not supported natively by some DBs.
