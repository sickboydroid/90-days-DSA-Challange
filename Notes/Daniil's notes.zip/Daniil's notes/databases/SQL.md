# SQL

Structured Query Language - used for database management.

## Command kinds

- DDL (Data Definition Language) - used to create DB structure
- DML (Data Manipulation Language) - used for CRUD
- DCL (Data Control Language) - used for permission control
- TCL (Transaction Control Language) - used for transactions of DML

## Indexes

Indexes speed up the search process.
E.g. in string search, w/o index each row will be checked sequentially.
