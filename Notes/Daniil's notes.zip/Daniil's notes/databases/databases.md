# Databases

## ACID

ACID is a set of properties intended to guarantee database validity despite external errors.

- Atomicity - Each transaction does all or nothing
- Consistency - Any transaction will bring the database from one valid state to another
- Isolation - Executing transactions concurrently has the same results as if the transactions were executed serially
- Durability - Once a transaction has been committed, it will remain so
