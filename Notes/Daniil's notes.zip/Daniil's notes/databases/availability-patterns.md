# Availability patterns

Availability is the time when the system is functional.

## Fail-over

Failover is switching to a redundant system upon failure.

### Active-passive (master-slave)

One server is active and is sending heartbeats to the passive one.
If heartbeat is stopped, the passive server takes over the active's IP and starts working as active.

### Active-active (master-master)

Both servers are managing traffic, spreading the load between them.

## Replication

Same as [database replication](<./database replication.md#Database replication>)
