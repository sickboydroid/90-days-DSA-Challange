# Main points:
1. Use flashcards
2. Start doing interview questions about the topics you've learned as you're learning them
3. Review your cheat sheets

Use spaced repetition. When learning a new subject, read/watch/practice a lot on the first day.  
A few days later, return to the topic, review your knowledge and learn a bit more about this topic.  
Flashcards are useful with this.  
